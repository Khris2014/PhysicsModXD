# BlenderPhysics: Crystal Fluid & SoftBody Engine

Mod de Fabric para Minecraft **1.21.1** (Yarn `1.21.1+build.3`, Fabric Loader `0.16.9+`,
Fabric API `0.105.0+1.21.1`, Java 21) que añade un motor de físicas de fluidos (SPH) y
cuerpos rígidos/blandos, con un pipeline de renderizado "Screen-Space Fluid Rendering"
estilo Blender Cycles/Eevee (agua cristalina, nunca opaca/leche).

## Cómo compilar

```bash
./gradlew build
```

El `.jar` final queda en `build/libs/blenderphysics-1.0.0.jar`.

> **Importante — compilación no verificada en este entorno.** Este proyecto fue generado
> en un entorno sin acceso de red a `maven.fabricmc.net`, `libraries.minecraft.net` ni
> Maven Central, por lo que **no fue posible ejecutar `./gradlew build` ni descargar
> Minecraft/Yarn/Fabric API para compilar y depurar de verdad**. Todo el código se
> escribió con cuidado contra las firmas de API conocidas de Yarn para 1.21.1, y se
> validó estáticamente (JSON válidos, balance de llaves/paréntesis ignorando comentarios
> y strings, referencias cruzadas entre registros Java ↔ modelos ↔ blockstates ↔ texturas
> ↔ claves de traducción — ver sección "Validación realizada"), pero **la primera vez que
> ejecutes `./gradlew build` en tu máquina es posible que aparezcan algunos errores de
> compilación por pequeños desajustes de nombres de métodos entre builds de Yarn**
> (especialmente en `PhysicsRigidBodyEntity` — serialización NBT/spawn packet — y en
> `FluidRenderPipeline` — subida final de buffers a GPU, marcada explícitamente con
> comentarios `NOTA` en el código). Son ajustes puntuales, no errores de diseño.

## Validación realizada sin compilador real

- ✅ 36/36 archivos JSON (modelos, blockstates, recetas, idiomas, shaders `.json`) parsean sin error.
- ✅ 37/37 archivos `.java` tienen llaves `{}` y paréntesis `()` balanceados (ignorando comentarios y literales de texto).
- ✅ Todas las texturas referenciadas por los modelos de ítems/bloques existen como PNG 16×16 reales.
- ✅ Todas las claves de traducción usadas en `Text.translatable(...)` existen en `en_us.json` y `es_es.json`.
- ✅ Los 3 identificadores de core shader (`fluid_depth`, `bilateral_blur`, `fluid_composite`) usados en `FluidRenderPipeline` coinciden exactamente con los archivos `.vsh`/`.fsh`/`.json` presentes en `shaders/core/`.
- ⚠️ No se pudo verificar contra el compilador real de Java + las librerías de Minecraft/Yarn/Fabric (sin red).

## Puntos a revisar tú mismo al compilar (lista corta)

1. **`PhysicsRigidBodyEntity`**: los métodos `readCustomDataFromNbt`/`writeCustomDataToNbt`/
   `createSpawnPacket` usan las firmas de Yarn `1.21.1+build.3`; en builds de Yarn muy
   cercanas estos nombres a veces cambian de forma menor.
2. **`FluidRenderPipeline`**: la subida final de `BufferBuilder` a la GPU
   (`BufferBuilder.end()` + `BufferRenderer.draw(...)`) se dejó marcada con comentarios
   `NOTA` porque la firma exacta varía entre snapshots de Minecraft 1.21.x; soluciónalo
   mirando cualquier mod que use `WorldRenderEvents.AFTER_TRANSLUCENT` con buffers
   manuales como referencia rápida.
3. **`pack.mcmeta`**: `pack_format: 48` es el valor usado para 1.21.x; confírmalo contra
   la wiki de Minecraft para tu build exacta de 1.21.1 si Minecraft marca el pack como
   incompatible al cargar (no es un error fatal, solo pide confirmación).

## Controles

- **Tecla `O`** (configurable en Opciones > Controles > Blender Physics): abre el menú
  de configuración en vivo (3 pestañas: Rendimiento, Apariencia Visual, Físicas del Mundo).
- **`/bp configui`**: mismo menú, por comando (cliente).
- **`/bp clear`**: limpia todas las simulaciones (requiere permisos de operador).

## Resumen de contenido

- **Varita de Realismo** (`reality_wand`): convierte bloques sólidos en entidades físicas
  3D, ítems tirados en objetos con hitbox, y agua/lava/slime **vanilla** en partículas de
  fluido realista (sin destruir el mundo natural). 4 modos con Shift+Click derecho.
- **Cubos realistas**, **bombas lanzables** y **bloques emisores/desagüe** — todos
  generan/eliminan partículas de simulación, nunca bloques de fluido vanilla.
- **Motor SPH multihilo** con spatial hash grid en arreglos primitivos (cero basura de GC).
- **Pipeline SSFR anti-leche**: depth+thickness map → blur bilateral → composición con
  Beer-Lambert, refracción, Fresnel/especular y espuma controlada (≤35% alpha, solo con
  turbulencia real).
- Traducciones completas en inglés y español.
