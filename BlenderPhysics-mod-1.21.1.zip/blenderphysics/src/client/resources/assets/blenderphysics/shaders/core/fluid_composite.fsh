#version 150

uniform sampler2D DepthThicknessSampler; // r = profundidad suavizada, g = grosor (thickness) suavizado
uniform sampler2D SceneColorSampler;     // color del mundo ya renderizado (para refracción/Fresnel de fondo)
uniform sampler2D SceneDepthSampler;     // profundidad del mundo (para no refractar a través de geometría opaca)
uniform sampler2D SkySampler;            // aproximación de color de cielo para el reflejo Fresnel

uniform vec2 InSize;
uniform vec3 AbsorptionColor;     // vec3(0.45, 0.12, 0.04) tal como pide la especificación Beer-Lambert
uniform float AbsorptionScale;    // controlado por "Transparencia / Claridad del Agua" (0.1 - 2.0)
uniform float RefractionStrength; // controlado por "Intensidad de Refracción" (0.0 - 1.0)
uniform float FoamAmount;         // controlado por "Cantidad de Espuma Blanca" (0.0 - 0.30)
uniform float FluidKind;          // 0 = agua, 1 = lava, 2 = slime
uniform float LavaEmission;       // controlado por "Brillo / Emisión de Lava" (0.5 - 2.0)
uniform float Time;
uniform vec3 SunDirection;

in vec2 texCoord;
out vec4 fragColor;

/*
 * fluid_composite.fsh  —  EL SHADER "ANTI-LECHE"
 * ================================================
 * Esta es la pasada final del pipeline SSFR. Toma el Depth/Thickness Map ya suavizado por
 * el blur bilateral y reconstruye un líquido físicamente plausible al estilo Blender
 * Cycles/Eevee, cumpliendo estrictamente las reglas de diseño del mod:
 *
 *  1. Reconstrucción de normales 3D a partir de derivadas del depth suavizado (nunca de
 *     las partículas individuales), lo que da una superficie orgánica continua.
 *  2. Absorción Beer-Lambert: transmittance = exp(-absorption * thickness). Las capas
 *     finas (bordes, gotas) dejan pasar casi toda la luz -> prácticamente invisibles /
 *     cristalinas. Las zonas profundas absorben el rojo rápido y el azul lento -> tono
 *     azul-turquesa realista, JAMÁS blanco/opaco.
 *  3. Refracción: las coordenadas de muestreo del color de fondo (el mundo ya renderizado
 *     detrás del fluido) se desplazan según la normal reconstruida, distorsionando los
 *     bloques bajo el agua igual que una superficie refractante real.
 *  4. Fresnel + especular Blinn-Phong de exponente alto: en ángulos rasantes se mezcla el
 *     color de fondo refractado con un reflejo del "cielo" + un brillo solar nítido.
 *  5. Espuma: SOLO aparece si hay turbulencia real (derivada de velocidad aproximada por
 *     el gradiente de thickness) Y supera un umbral; usa ruido Voronoi/Perlin de baja
 *     amplitud (alpha <= 0.35) para parecer burbujas finas, nunca una mancha blanca sólida.
 *     Por defecto FoamAmount = 0.05 limita su presencia global a ese porcentaje.
 */

// ---- Ruido de valor simple (sustituto ligero de Perlin, barato en GPU) ----
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float valueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

// ---- Voronoi barato de una celda (para burbujas de espuma) ----
float voronoiNoise(vec2 p) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    float minDist = 1.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 neighbor = vec2(float(x), float(y));
            vec2 point_ = vec2(hash(ip + neighbor), hash(ip + neighbor + 7.0));
            vec2 diff = neighbor + point_ - fp;
            minDist = min(minDist, length(diff));
        }
    }
    return minDist;
}

vec3 reconstructNormal(vec2 uv, float centerDepth) {
    vec2 texel = 1.0 / InSize;
    float depthL = texture(DepthThicknessSampler, uv - vec2(texel.x, 0.0)).r;
    float depthR = texture(DepthThicknessSampler, uv + vec2(texel.x, 0.0)).r;
    float depthD = texture(DepthThicknessSampler, uv - vec2(0.0, texel.y)).r;
    float depthU = texture(DepthThicknessSampler, uv + vec2(0.0, texel.y)).r;

    // Derivadas de profundidad en espacio de vista aproximado -> pendiente de superficie
    float ddx = (depthR - depthL) * 0.5;
    float ddy = (depthU - depthD) * 0.5;

    vec3 normal = normalize(vec3(-ddx * 8.0, -ddy * 8.0, 1.0));
    return normal;
}

void main() {
    vec4 fluidSample = texture(DepthThicknessSampler, texCoord);
    float thickness = fluidSample.g;

    if (fluidSample.a < 0.001 || thickness <= 0.0001) {
        discard; // no hay fluido en este píxel: deja ver la escena normal sin tocar nada
    }

    vec3 normal = reconstructNormal(texCoord, fluidSample.r);

    // --- Refracción: desplaza el muestreo del color de fondo según la normal ---
    vec2 refractOffset = normal.xy * RefractionStrength * 0.06;
    vec2 refractedUV = clamp(texCoord + refractOffset, vec2(0.001), vec2(0.999));

    // Evita refractar "a través" de geometría que está delante del fluido (error de profundidad)
    float sceneDepth = texture(SceneDepthSampler, refractedUV).r;
    vec3 backgroundColor = texture(SceneColorSampler, refractedUV).rgb;

    vec3 viewDir = normalize(vec3(0.0, 0.0, 1.0));
    float ndotv = clamp(dot(normal, viewDir), 0.0, 1.0);

    // === Lava: material incandescente, no sigue la rama de absorción transparente ===
    if (FluidKind > 0.5 && FluidKind < 1.5) {
        float crust = valueNoise(texCoord * InSize * 0.04 + Time * 0.02);
        vec3 hotColor = mix(vec3(1.0, 0.2, 0.0), vec3(1.0, 0.65, 0.0), clamp(thickness * 1.5, 0.0, 1.0));
        vec3 crustColor = vec3(0.10, 0.05, 0.04);
        float crustMask = smoothstep(0.55, 0.75, crust);
        vec3 lavaColor = mix(hotColor, crustColor, crustMask) * LavaEmission;
        fragColor = vec4(lavaColor, 1.0);
        return;
    }

    // === Slime: viscoelástico translúcido con dispersión subsuperficial simulada ===
    if (FluidKind > 1.5) {
        vec3 slimeBase = vec3(0.196, 0.910, 0.325); // #32E852
        vec3 transmittanceSlime = exp(-vec3(0.9, 0.25, 0.9) * thickness * AbsorptionScale);
        vec3 thinEdgeGlow = slimeBase * (1.0 - transmittanceSlime) * 1.4; // más claro en bordes finos
        vec3 slimeColor = mix(slimeBase * 0.5, thinEdgeGlow + backgroundColor * transmittanceSlime, 0.85);
        float fresnelSlime = pow(1.0 - ndotv, 4.0) * 0.4;
        vec3 skyReflectSlime = texture(SkySampler, refractedUV).rgb;
        slimeColor = mix(slimeColor, skyReflectSlime, fresnelSlime);
        fragColor = vec4(slimeColor, 1.0);
        return;
    }

    // === Agua: la rama principal "anti-leche" ===
    // Ley de Beer-Lambert: cuanto más grosor, más absorción. Finas capas casi no absorben nada.
    vec3 transmittance = exp(-AbsorptionColor * thickness * AbsorptionScale);
    vec3 absorbedColor = backgroundColor * transmittance;

    // Reflejo Fresnel (Schlick) con F0 bajo, típico del agua
    float F0 = 0.02;
    float fresnel = F0 + (1.0 - F0) * pow(1.0 - ndotv, 5.0);

    vec3 skyColor = texture(SkySampler, refractedUV).rgb;

    // Especular Blinn-Phong de exponente alto para brillos solares nítidos
    vec3 halfVec = normalize(SunDirection + viewDir);
    float specAngle = clamp(dot(normal, halfVec), 0.0, 1.0);
    float specular = pow(specAngle, 128.0);

    vec3 waterColor = mix(absorbedColor, skyColor, fresnel);
    waterColor += vec3(1.0) * specular * 0.9;

    // --- Espuma ultra-discreta: solo con turbulencia real y nunca como mancha sólida ---
    float thicknessGradient = length(vec2(dFdx(thickness), dFdy(thickness)));
    float turbulence = smoothstep(0.015, 0.05, thicknessGradient);
    float foamThreshold = 0.6; // análogo a particleVelocity > foamThreshold en el solver
    float foamNoise = voronoiNoise(texCoord * InSize * 0.08 + Time * 0.5);
    float foamMask = turbulence * smoothstep(foamThreshold, 1.0, 1.0 - foamNoise);
    float foamAlpha = clamp(foamMask * FoamAmount * 6.0, 0.0, 0.35); // alpha <= 0.35, nunca sólido

    vec3 finalColor = mix(waterColor, vec3(1.0), foamAlpha);

    fragColor = vec4(finalColor, 1.0);
}
