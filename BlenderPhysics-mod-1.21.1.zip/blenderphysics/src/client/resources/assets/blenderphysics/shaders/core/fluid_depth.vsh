#version 150

in vec3 Position;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float ParticleRadius;

out float vViewDepth;
out float vThicknessContribution;

/*
 * fluid_depth.vsh
 * Primera pasada del pipeline SSFR (Screen-Space Fluid Rendering):
 * dibuja cada partícula de fluido como una micro-esfera (point sprite expandido en el
 * fragment shader) y escribe en un FBO auxiliar:
 *   - el canal rojo del Depth Map: profundidad de vista (view-space) de la superficie del fluido.
 *   - el canal verde: contribución de grosor acumulada (Thickness Map), usada luego por el
 *     shader de composición para la absorción Beer-Lambert.
 * Esto es lo que permite fusionar miles de partículas en una "malla líquida" lisa y
 * continua en vez de ver bolitas separadas.
 */
void main() {
    vec4 viewPos = ModelViewMat * vec4(Position, 1.0);
    vViewDepth = -viewPos.z;
    vThicknessContribution = ParticleRadius * 2.0;
    gl_Position = ProjMat * viewPos;
    gl_PointSize = max(2.0, ParticleRadius * 600.0 / max(0.1, vViewDepth));
}
