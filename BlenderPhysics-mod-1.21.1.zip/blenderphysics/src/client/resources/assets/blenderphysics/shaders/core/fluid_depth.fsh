#version 150

in float vViewDepth;
in float vThicknessContribution;

out vec4 fragColor;

/*
 * fluid_depth.fsh
 * Recorta el point-sprite a un disco (una esfera 2D proyectada) descartando las esquinas,
 * y escribe profundidad + grosor. El recorte circular es lo que, tras el blur bilateral,
 * produce una superficie orgánica suave en vez de cuadrados visibles.
 */
void main() {
    vec2 uv = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(uv, uv);
    if (r2 > 1.0) discard;

    float sphereZ = sqrt(1.0 - r2);
    float depth = vViewDepth - sphereZ * (vThicknessContribution * 0.5);

    fragColor = vec4(depth, vThicknessContribution * sphereZ, 0.0, 1.0);
}
