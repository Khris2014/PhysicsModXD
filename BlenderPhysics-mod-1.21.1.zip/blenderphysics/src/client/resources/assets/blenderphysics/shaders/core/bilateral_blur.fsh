#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 BlurDir;       // (1,0) pasada horizontal, (0,1) pasada vertical
uniform vec2 InSize;
uniform float DepthThreshold;

in vec2 texCoord;
out vec4 fragColor;

/*
 * bilateral_blur.fsh
 * Filtro Gaussiano Bilateral de 9 muestras sobre el Depth/Thickness Map.
 * A diferencia de un blur gaussiano normal, pondera cada muestra vecina no solo por su
 * distancia espacial (gaussiana estándar) sino también por cuánto se diferencia su
 * profundidad de la del píxel central (peso de rango). Esto funde las partículas
 * cercanas en una malla lisa y orgánica SIN emborronar los bordes afilados entre el
 * fluido y el fondo del mundo (ni mezclar profundidades de superficies muy distintas).
 */
float gaussian(float x, float sigma) {
    return exp(-(x * x) / (2.0 * sigma * sigma));
}

void main() {
    vec4 center = texture(DiffuseSampler, texCoord);
    if (center.a < 0.001) {
        fragColor = center;
        return;
    }
    float centerDepth = center.r;

    float sigmaSpatial = 3.2;
    float sigmaRange = DepthThreshold;

    vec2 texel = BlurDir / InSize;

    float sumWeight = 0.0;
    vec2 sumValue = vec2(0.0);

    for (int i = -4; i <= 4; i++) {
        vec2 offset = texel * float(i);
        vec4 sample_ = texture(DiffuseSampler, texCoord + offset);
        if (sample_.a < 0.001) continue;

        float spatialW = gaussian(float(i), sigmaSpatial);
        float rangeW = gaussian(sample_.r - centerDepth, sigmaRange);
        float w = spatialW * rangeW;

        sumValue += sample_.rg * w;
        sumWeight += w;
    }

    if (sumWeight < 0.0001) {
        fragColor = center;
    } else {
        fragColor = vec4(sumValue / sumWeight, 0.0, 1.0);
    }
}
