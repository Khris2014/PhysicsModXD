package com.blenderphysics.client.gui;

import com.blenderphysics.config.BlenderPhysicsConfig;
import com.blenderphysics.config.WaterShaderQuality;
import com.blenderphysics.physics.PhysicsManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

/**
 * Menú de configuración en vivo del mod (3 pestañas): Rendimiento, Apariencia Visual y
 * Físicas del Mundo. Todos los cambios se aplican inmediatamente (lectura directa desde
 * {@link BlenderPhysicsConfig#get()} por el motor de físicas y el shader) y se guardan en
 * config/blenderphysics.json al cerrar la pantalla o al pulsar cualquier control.
 */
public class BlenderPhysicsConfigScreen extends Screen {

	private enum Tab { PERFORMANCE, VISUAL, WORLD_PHYSICS }

	private final Screen parent;
	private final BlenderPhysicsConfig cfg;
	private Tab currentTab = Tab.PERFORMANCE;

	private static final int PANEL_WIDTH = 360;
	private static final int ROW_HEIGHT = 24;

	public BlenderPhysicsConfigScreen(Screen parent) {
		super(Text.translatable("blenderphysics.config.title"));
		this.parent = parent;
		this.cfg = BlenderPhysicsConfig.get();
	}

	@Override
	protected void init() {
		super.init();
		int centerX = this.width / 2;
		int tabY = 28;
		int tabWidth = PANEL_WIDTH / 3 - 4;

		addDrawableChild(ButtonWidget.builder(Text.translatable("blenderphysics.config.tab.performance"),
						b -> switchTab(Tab.PERFORMANCE))
				.dimensions(centerX - PANEL_WIDTH / 2, tabY, tabWidth, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("blenderphysics.config.tab.visual"),
						b -> switchTab(Tab.VISUAL))
				.dimensions(centerX - PANEL_WIDTH / 2 + tabWidth + 6, tabY, tabWidth, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("blenderphysics.config.tab.world"),
						b -> switchTab(Tab.WORLD_PHYSICS))
				.dimensions(centerX - PANEL_WIDTH / 2 + (tabWidth + 6) * 2, tabY, tabWidth, 20).build());

		buildTabContent();

		addDrawableChild(ButtonWidget.builder(Text.translatable("blenderphysics.config.done"), b -> close())
				.dimensions(centerX - 100, this.height - 28, 200, 20).build());
	}

	private void switchTab(Tab tab) {
		this.currentTab = tab;
		this.clearChildren();
		init();
	}

	private void buildTabContent() {
		int centerX = this.width / 2;
		int left = centerX - PANEL_WIDTH / 2;
		int y = 60;

		switch (currentTab) {
			case PERFORMANCE -> buildPerformanceTab(left, y);
			case VISUAL -> buildVisualTab(left, y);
			case WORLD_PHYSICS -> buildWorldTab(left, y);
		}
	}

	private void buildPerformanceTab(int left, int y) {
		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20,
				BlenderPhysicsConfig.MIN_PARTICLES, BlenderPhysicsConfig.MAX_PARTICLES, cfg.maxParticles, true,
				v -> Text.translatable("blenderphysics.config.max_particles", v.intValue()),
				v -> { cfg.maxParticles = v.intValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20,
				BlenderPhysicsConfig.MIN_RADIUS, BlenderPhysicsConfig.MAX_RADIUS, cfg.simulationRadius, true,
				v -> Text.translatable("blenderphysics.config.sim_radius", v.intValue()),
				v -> { cfg.simulationRadius = v.intValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(CyclingButtonWidget.<WaterShaderQuality>builder(q -> Text.translatable(q.getTranslationKey()))
				.values(WaterShaderQuality.values())
				.initially(cfg.waterShaderQuality)
				.build(left, y, PANEL_WIDTH, 20, Text.translatable("blenderphysics.config.water_quality"),
						(button, value) -> { cfg.waterShaderQuality = value; cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20,
				BlenderPhysicsConfig.MIN_SUBSTEPS, BlenderPhysicsConfig.MAX_SUBSTEPS, cfg.physicsSubsteps, true,
				v -> Text.translatable("blenderphysics.config.substeps", v.intValue()),
				v -> { cfg.physicsSubsteps = v.intValue(); cfg.save(); }));
		y += ROW_HEIGHT + 6;

		addDrawableChild(ButtonWidget.builder(Text.translatable("blenderphysics.config.clear_now").formatted(net.minecraft.util.Formatting.RED),
						b -> {
							PhysicsManager.get().clearAll();
							if (MinecraftClient.getInstance().getNetworkHandler() != null) {
								MinecraftClient.getInstance().getNetworkHandler().sendCommand("bp clear");
							}
						})
				.dimensions(left, y, PANEL_WIDTH, 20).build());
	}

	private void buildVisualTab(int left, int y) {
		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.1, 2.0, cfg.waterClarity, false,
				v -> Text.translatable("blenderphysics.config.water_clarity", String.format("%.2f", v)),
				v -> { cfg.waterClarity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.0, 0.30, cfg.foamAmount, false,
				v -> Text.translatable("blenderphysics.config.foam_amount", Math.round(v * 100)),
				v -> { cfg.foamAmount = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.0, 1.0, cfg.refractionIntensity, false,
				v -> Text.translatable("blenderphysics.config.refraction", String.format("%.2f", v)),
				v -> { cfg.refractionIntensity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.5, 2.0, cfg.lavaEmission, false,
				v -> Text.translatable("blenderphysics.config.lava_emission", String.format("%.2f", v)),
				v -> { cfg.lavaEmission = v.floatValue(); cfg.save(); }));
	}

	private void buildWorldTab(int left, int y) {
		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, -2.0, 2.0, cfg.gravity, false,
				v -> Text.translatable("blenderphysics.config.gravity", String.format("%.2f", v)),
				v -> { cfg.gravity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.0, 5.0, cfg.waterViscosity, false,
				v -> Text.translatable("blenderphysics.config.viscosity_water", String.format("%.2f", v)),
				v -> { cfg.waterViscosity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.0, 5.0, cfg.lavaViscosity, false,
				v -> Text.translatable("blenderphysics.config.viscosity_lava", String.format("%.2f", v)),
				v -> { cfg.lavaViscosity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(new LabeledSlider(left, y, PANEL_WIDTH, 20, 0.0, 5.0, cfg.slimeViscosity, false,
				v -> Text.translatable("blenderphysics.config.viscosity_slime", String.format("%.2f", v)),
				v -> { cfg.slimeViscosity = v.floatValue(); cfg.save(); }));
		y += ROW_HEIGHT;

		addDrawableChild(CyclingButtonWidget.onOffBuilder(cfg.playerPushEnabled)
				.build(left, y, PANEL_WIDTH, 20, Text.translatable("blenderphysics.config.player_push"),
						(button, value) -> { cfg.playerPushEnabled = value; cfg.save(); }));
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		this.renderBackground(context, mouseX, mouseY, delta);
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);
	}

	@Override
	public void close() {
		cfg.save();
		if (this.client != null) this.client.setScreen(parent);
	}
}
