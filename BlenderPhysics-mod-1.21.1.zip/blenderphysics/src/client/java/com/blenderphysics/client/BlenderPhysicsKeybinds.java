package com.blenderphysics.client;

import com.blenderphysics.BlenderPhysicsMod;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Tecla rápida para abrir el menú de configuración de BlenderPhysics. Por defecto 'O'
 * (sin conflicto con los controles vanilla), reasignable libremente en
 * Opciones > Controles > Blender Physics, como pide la regla de diseño #3.
 */
public final class BlenderPhysicsKeybinds {

	public static final String CATEGORY = "key.categories." + BlenderPhysicsMod.MOD_ID;

	public static KeyBinding OPEN_CONFIG;

	private BlenderPhysicsKeybinds() {
	}

	public static void register() {
		OPEN_CONFIG = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key." + BlenderPhysicsMod.MOD_ID + ".open_config",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_O,
				CATEGORY
		));
	}
}
