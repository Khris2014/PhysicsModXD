package com.blenderphysics.client;

import com.blenderphysics.client.gui.BlenderPhysicsConfigScreen;
import com.blenderphysics.client.render.FluidRenderPipeline;
import com.blenderphysics.registry.ModEntities;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Entrypoint de cliente: registra la tecla rápida, el comando "/bp configui", los
 * renderizadores de entidades y el pipeline de renderizado SSFR (Screen-Space Fluid
 * Rendering) anti-leche.
 */
public class BlenderPhysicsClientMod implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		BlenderPhysicsKeybinds.register();

		EntityRendererRegistry.register(ModEntities.PHYSICS_RIGID_BODY, PhysicsRigidBodyEntityRenderer::new);
		EntityRendererRegistry.register(ModEntities.WATER_BOMB_ENTITY, ctx -> new FluidBombEntityRenderer(ctx, "water_bomb"));
		EntityRendererRegistry.register(ModEntities.LAVA_BOMB_ENTITY, ctx -> new FluidBombEntityRenderer(ctx, "lava_bomb"));
		EntityRendererRegistry.register(ModEntities.SLIME_BOMB_ENTITY, ctx -> new FluidBombEntityRenderer(ctx, "slime_bomb"));

		FluidRenderPipeline.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (BlenderPhysicsKeybinds.OPEN_CONFIG.wasPressed()) {
				client.setScreen(new BlenderPhysicsConfigScreen(client.currentScreen));
			}
		});

		ClientCommandManager.DISPATCHER.register(
				literal("bp").then(literal("configui").executes(this::openConfigUi)));
	}

	private int openConfigUi(CommandContext<FabricClientCommandSource> ctx) {
		MinecraftClient client = MinecraftClient.getInstance();
		client.execute(() -> client.setScreen(new BlenderPhysicsConfigScreen(client.currentScreen)));
		return 1;
	}
}
