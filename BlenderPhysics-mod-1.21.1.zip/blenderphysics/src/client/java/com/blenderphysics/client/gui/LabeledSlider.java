package com.blenderphysics.client.gui;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Slider genérico reutilizado por las 3 pestañas del menú: interpola entre [min, max]
 * usando el valor normalizado [0,1] interno de SliderWidget, y formatea la etiqueta con
 * el valor real actual.
 */
public class LabeledSlider extends SliderWidget {

	private final double min;
	private final double max;
	private final Function<Double, Text> labelFormatter;
	private final Consumer<Double> onChange;
	private final boolean integerStep;

	public LabeledSlider(int x, int y, int width, int height, double min, double max, double initialValue,
			boolean integerStep, Function<Double, Text> labelFormatter, Consumer<Double> onChange) {
		super(x, y, width, height, Text.empty(), clamp((initialValue - min) / (max - min)));
		this.min = min;
		this.max = max;
		this.integerStep = integerStep;
		this.labelFormatter = labelFormatter;
		this.onChange = onChange;
		updateMessage();
	}

	private static double clamp(double v) {
		return Math.max(0.0, Math.min(1.0, v));
	}

	public double realValue() {
		double v = min + (max - min) * this.value;
		return integerStep ? Math.round(v) : v;
	}

	@Override
	protected void updateMessage() {
		setMessage(labelFormatter.apply(realValue()));
	}

	@Override
	protected void applyValue() {
		onChange.accept(realValue());
	}
}
