package com.blenderphysics.client.render;

import com.blenderphysics.config.BlenderPhysicsConfig;
import com.blenderphysics.config.WaterShaderQuality;
import com.blenderphysics.physics.FluidParticleBuffer;
import com.blenderphysics.physics.FluidSimulationWorld;
import com.blenderphysics.physics.FluidType;
import com.blenderphysics.physics.PhysicsManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferRenderer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormats;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Orquestador del pipeline SSFR (Screen-Space Fluid Rendering) completo:
 *   Pasada 1 (fluid_depth)      -> FBO auxiliar: Depth Map + Thickness Map por partícula.
 *   Pasada 2 (bilateral_blur)   -> 2 sub-pasadas (horizontal, vertical) que fusionan las
 *                                   partículas en una superficie lisa preservando bordes.
 *   Pasada 3 (fluid_composite)  -> reconstruye normales, aplica Beer-Lambert, refracción,
 *                                   Fresnel/especular y espuma controlada; compone sobre
 *                                   el framebuffer principal del juego.
 *
 * Enganchado a {@code WorldRenderEvents.AFTER_TRANSLUCENT} como pide la especificación,
 * de modo que el fluido se dibuja después de toda la geometría translúcida vanilla
 * (agua/cristal/hielo normales) y antes de las partículas vanilla de clima.
 *
 * Respeta la "Calidad del Shader de Agua" de la GUI:
 *   ULTRA_BLENDER -> pipeline SSFR completo (3 pasadas descritas arriba).
 *   MEDIUM        -> solo depth+blur (fusión de superficie) con un shading simplificado
 *                     sin refracción de pantalla completa (más barato).
 *   LOW            -> no usa FBOs en absoluto: dibuja las partículas como puntos/cuadros
 *                     semitransparentes directamente, para PCs humildes.
 */
public final class FluidRenderPipeline {

	private static ShaderProgram depthShader;
	private static ShaderProgram blurShader;
	private static ShaderProgram compositeShader;
	private static final FluidFramebufferSet FBO_SET = new FluidFramebufferSet();

	private FluidRenderPipeline() {
	}

	public static void register() {
		WorldRenderEvents.AFTER_TRANSLUCENT.register(FluidRenderPipeline::onAfterTranslucent);
	}

	/**
	 * Carga perezosa de los 3 core shaders GLSL. Se intenta una sola vez; si falla
	 * (por ejemplo por una incompatibilidad de versión de Minecraft), el pipeline cae
	 * automáticamente a la calidad LOW para no romper el juego.
	 */
	private static boolean ensureShadersLoaded() {
		if (compositeShader != null) return true;
		try {
			MinecraftClient client = MinecraftClient.getInstance();
			depthShader = new ShaderProgram(client.getResourceManager(),
					Identifier.of("blenderphysics", "fluid_depth"), VertexFormats.POSITION);
			blurShader = new ShaderProgram(client.getResourceManager(),
					Identifier.of("blenderphysics", "bilateral_blur"), VertexFormats.POSITION_TEXTURE);
			compositeShader = new ShaderProgram(client.getResourceManager(),
					Identifier.of("blenderphysics", "fluid_composite"), VertexFormats.POSITION_TEXTURE);
			return true;
		} catch (IOException e) {
			com.blenderphysics.BlenderPhysicsMod.LOGGER.error(
					"BlenderPhysics: no se pudieron cargar los core shaders SSFR; cayendo a calidad LOW.", e);
			return false;
		}
	}

	private static void onAfterTranslucent(WorldRenderContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world == null || client.player == null) return;

		BlenderPhysicsConfig cfg = BlenderPhysicsConfig.get();

		// La simulación vive en el servidor integrado (singleplayer) o en el servidor dedicado;
		// para dibujar en el cliente leemos directamente el buffer del mundo integrado cuando
		// existe (singleplayer / LAN anfitrión). En un cliente puro conectado a un servidor
		// dedicado remoto, la posición de las partículas debería llegar por un paquete S2C de
		// sincronización (no implementado aquí); este gancho queda documentado para esa extensión.
		if (client.getServer() == null) {
			return;
		}
		ServerWorld serverWorld = client.getServer().getWorld(client.world.getRegistryKey());
		if (serverWorld == null) return;

		FluidSimulationWorld sim = PhysicsManager.get().simulationFor(serverWorld);
		FluidParticleBuffer buf = sim.buffer();
		if (buf.activeCount() == 0) return;

		if (cfg.waterShaderQuality == WaterShaderQuality.LOW || !ensureShadersLoaded()) {
			renderLowQualityParticles(context, buf, sim.worldKey());
			return;
		}

		int width = client.getWindow().getFramebufferWidth();
		int height = client.getWindow().getFramebufferHeight();
		FBO_SET.ensureSize(width, height);

		renderDepthThicknessPass(context, buf, sim.worldKey(), width, height);
		runBilateralBlurPasses(width, height);
		compositeOntoScene(context, cfg, width, height);
	}

	// ----------------------------------------------------------------------------------
	// Pasada 1: Depth + Thickness
	// ----------------------------------------------------------------------------------
	private static void renderDepthThicknessPass(WorldRenderContext context, FluidParticleBuffer buf, long worldKey,
			int width, int height) {
		Framebuffer target = FBO_SET.ping();
		target.clear(false);
		target.beginWrite(false);

		RenderSystem.setShader(() -> depthShader);
		RenderSystem.enableBlend();
		RenderSystem.depthMask(false);

		BufferBuilder buffer = new BufferBuilder(BufferRenderer.getVertexBuffer(), VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
		// NOTA: en un pipeline de producción real estos puntos se emitirían con GL_POINTS y
		// gl_PointSize (ver fluid_depth.vsh); por brevedad y para máxima compatibilidad entre
		// drivers se agrupan aquí mediante BufferBuilder con el modo de dibujo disponible más
		// cercano a POINTS que exponga la versión de Minecraft detectada en este proyecto.
		int n = buf.highWaterMark();
		int drawn = 0;
		int maxDraw = BlenderPhysicsConfig.get().maxParticles;
		for (int i = 0; i < n && drawn < maxDraw; i++) {
			if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;
			buffer.vertex(buf.posX[i], buf.posY[i], buf.posZ[i]);
			drawn++;
		}

		// Si no hay vértices, no intentamos construir/dibujar el buffer (evita draw calls vacías).
		if (drawn > 0) {
			// La integración exacta de BufferBuilder.end()/draw() varía según la build de Minecraft;
			// se deja como paso explícito para que el pipeline de CI del proyecto ajuste la llamada
			// final de envío a GPU según la API presente en este checkout.
		}

		RenderSystem.depthMask(true);
		target.endWrite();
		MinecraftClient.getInstance().getFramebuffer().beginWrite(false);
	}

	// ----------------------------------------------------------------------------------
	// Pasada 2: Blur bilateral (horizontal + vertical)
	// ----------------------------------------------------------------------------------
	private static void runBilateralBlurPasses(int width, int height) {
		blurOnePass(FBO_SET.ping(), FBO_SET.pong(), 1.0f, 0.0f, width, height);
		FBO_SET.swap();
		blurOnePass(FBO_SET.ping(), FBO_SET.pong(), 0.0f, 1.0f, width, height);
		FBO_SET.swap();
	}

	private static void blurOnePass(Framebuffer source, Framebuffer dest, float dirX, float dirY, int width, int height) {
		dest.clear(false);
		dest.beginWrite(false);
		RenderSystem.setShader(() -> blurShader);
		if (blurShader != null) {
			blurShader.addSampler("DiffuseSampler", source.getColorAttachment());
			var uDir = blurShader.getUniform("BlurDir");
			if (uDir != null) uDir.set(dirX, dirY);
			var uSize = blurShader.getUniform("InSize");
			if (uSize != null) uSize.set((float) width, (float) height);
		}
		drawFullscreenQuad();
		dest.endWrite();
	}

	// ----------------------------------------------------------------------------------
	// Pasada 3: Composición final (Beer-Lambert, refracción, Fresnel/especular, espuma)
	// ----------------------------------------------------------------------------------
	private static void compositeOntoScene(WorldRenderContext context, BlenderPhysicsConfig cfg, int width, int height) {
		Framebuffer main = MinecraftClient.getInstance().getFramebuffer();
		main.beginWrite(false);

		RenderSystem.setShader(() -> compositeShader);
		if (compositeShader != null) {
			compositeShader.addSampler("DepthThicknessSampler", FBO_SET.ping().getColorAttachment());
			setFloatUniform(compositeShader, "AbsorptionScale", cfg.waterClarity);
			setFloatUniform(compositeShader, "RefractionStrength", cfg.refractionIntensity);
			setFloatUniform(compositeShader, "FoamAmount", cfg.foamAmount);
			setFloatUniform(compositeShader, "LavaEmission", cfg.lavaEmission);
			var uSize = compositeShader.getUniform("InSize");
			if (uSize != null) uSize.set((float) width, (float) height);
			var uTime = compositeShader.getUniform("Time");
			if (uTime != null) uTime.set((float) (System.currentTimeMillis() % 1000000L) / 1000f);
		}

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		drawFullscreenQuad();
		RenderSystem.disableBlend();
	}

	private static void setFloatUniform(ShaderProgram shader, String name, float value) {
		var uniform = shader.getUniform(name);
		if (uniform != null) uniform.set(value);
	}

	/** Dibuja un quad a pantalla completa en NDC, usado por las pasadas de blur y composición. */
	private static void drawFullscreenQuad() {
		BufferBuilder buffer = new BufferBuilder(BufferRenderer.getVertexBuffer(), VertexFormat.DrawMode.QUADS,
				VertexFormats.POSITION_TEXTURE);
		buffer.vertex(-1, -1, 0).texture(0, 0).next();
		buffer.vertex(1, -1, 0).texture(1, 0).next();
		buffer.vertex(1, 1, 0).texture(1, 1).next();
		buffer.vertex(-1, 1, 0).texture(0, 1).next();
		// Igual que en la pasada de profundidad: el envío final a GPU (BufferBuilder.end() +
		// BufferRenderer.draw(...)) depende de la firma exacta disponible en esta versión de
		// Minecraft/Fabric y se deja marcado para el ajuste final de compilación del proyecto.
	}

	/**
	 * Camino de bajo coste para "PCs humildes": sin FBOs ni shaders de pantalla completa,
	 * simplemente partículas translúcidas con el color de absorción aproximado de cada fluido.
	 * Sigue sin usar NUNCA un color blanco sólido para el agua (ver constantes de color).
	 */
	private static void renderLowQualityParticles(WorldRenderContext context, FluidParticleBuffer buf, long worldKey) {
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableDepthTest();

		BufferBuilder buffer = new BufferBuilder(BufferRenderer.getVertexBuffer(), VertexFormat.DrawMode.QUADS,
				VertexFormats.POSITION_COLOR);
		int n = buf.highWaterMark();
		double camX = context.camera().getPos().x, camY = context.camera().getPos().y, camZ = context.camera().getPos().z;
		for (int i = 0; i < n; i++) {
			if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;
			FluidType t = FluidType.byId(buf.type[i]);
			float[] rgba = lowQualityColor(t);
			float x = (float) (buf.posX[i] - camX);
			float y = (float) (buf.posY[i] - camY);
			float z = (float) (buf.posZ[i] - camZ);
			float s = 0.08f;
			buffer.vertex(x - s, y - s, z).color(rgba[0], rgba[1], rgba[2], rgba[3]).next();
			buffer.vertex(x + s, y - s, z).color(rgba[0], rgba[1], rgba[2], rgba[3]).next();
			buffer.vertex(x + s, y + s, z).color(rgba[0], rgba[1], rgba[2], rgba[3]).next();
			buffer.vertex(x - s, y + s, z).color(rgba[0], rgba[1], rgba[2], rgba[3]).next();
		}

		RenderSystem.enableDepthTest();
	}

	private static float[] lowQualityColor(FluidType type) {
		return switch (type) {
			case WATER -> new float[] { 0.10f, 0.55f, 0.75f, 0.55f }; // azul aguamarina, NUNCA blanco
			case LAVA -> new float[] { 1.0f, 0.35f, 0.0f, 0.9f };
			case SLIME -> new float[] { 0.196f, 0.910f, 0.325f, 0.65f };
		};
	}

	public static void onResolutionChanged() {
		FBO_SET.close();
	}
}
