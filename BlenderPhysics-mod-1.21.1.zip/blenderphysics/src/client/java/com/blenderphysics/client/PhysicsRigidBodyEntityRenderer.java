package com.blenderphysics.client;

import com.blenderphysics.entity.PhysicsRigidBodyEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Quaternionf;

/**
 * Dibuja la entidad física 3D: si proviene de un bloque, renderiza su BlockState exacto
 * (misma textura que tenía en el mundo) rotado por el cuaternión de físicas; si proviene
 * de un ítem, renderiza el modelo del ítem en modo "GROUND" también rotado libremente.
 */
public class PhysicsRigidBodyEntityRenderer extends EntityRenderer<PhysicsRigidBodyEntity> {

	public PhysicsRigidBodyEntityRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(PhysicsRigidBodyEntity entity) {
		return Identifier.of("minecraft", "textures/block/stone.png"); // no usado: el bloque se dibuja con su propio modelo
	}

	@Override
	public void render(PhysicsRigidBodyEntity entity, float yaw, float tickDelta, MatrixStack matrices,
			VertexConsumerProvider vertexConsumers, int light) {
		matrices.push();

		Quaternionf q = new Quaternionf(entity.rotation);
		matrices.multiply(q);

		MinecraftClient client = MinecraftClient.getInstance();
		if (entity.isBlockPayload() && entity.getSourceBlockState() != null) {
			matrices.translate(-0.5, -0.5, -0.5);
			BlockRenderManager blockRenderManager = client.getBlockRenderManager();
			blockRenderManager.renderBlockAsEntity(entity.getSourceBlockState(), matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
		} else if (!entity.getItemPayload().isEmpty()) {
			matrices.scale(0.5f, 0.5f, 0.5f);
			ItemRenderer itemRenderer = client.getItemRenderer();
			itemRenderer.renderItem(entity.getItemPayload(), ItemDisplayContext.GROUND, light, OverlayTexture.DEFAULT_UV,
					matrices, vertexConsumers, entity.getWorld(), 0);
		}

		matrices.pop();
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}
