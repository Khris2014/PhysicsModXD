package com.blenderphysics.client.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;

import static org.lwjgl.opengl.GL11.GL_LINEAR;
import static org.lwjgl.opengl.GL11.GL_NEAREST;

/**
 * Agrupa los framebuffers auxiliares necesarios para el pipeline SSFR:
 *  - depthThickness: canal r = profundidad de vista, canal g = grosor acumulado (ping)
 *  - depthThicknessPong: segundo buffer para el blur de 2 pasadas (horizontal/vertical)
 * Se recrean automáticamente si cambia la resolución de la ventana.
 */
public final class FluidFramebufferSet {

	private Framebuffer depthThicknessPing;
	private Framebuffer depthThicknessPong;
	private int width = -1;
	private int height = -1;

	public void ensureSize(int width, int height) {
		if (this.width == width && this.height == height && depthThicknessPing != null) return;
		close();
		this.width = width;
		this.height = height;
		this.depthThicknessPing = new SimpleFramebuffer(width, height, true, false);
		this.depthThicknessPong = new SimpleFramebuffer(width, height, true, false);
		configure(depthThicknessPing);
		configure(depthThicknessPong);
	}

	private void configure(Framebuffer fb) {
		fb.setClearColor(1.0e6f, 0.0f, 0.0f, 0.0f); // profundidad "infinita" => no hay fluido ahí
		fb.clear(false);
	}

	public Framebuffer ping() {
		return depthThicknessPing;
	}

	public Framebuffer pong() {
		return depthThicknessPong;
	}

	public void swap() {
		Framebuffer tmp = depthThicknessPing;
		depthThicknessPing = depthThicknessPong;
		depthThicknessPong = tmp;
	}

	public void close() {
		if (depthThicknessPing != null) depthThicknessPing.delete();
		if (depthThicknessPong != null) depthThicknessPong.delete();
		depthThicknessPing = null;
		depthThicknessPong = null;
	}
}
