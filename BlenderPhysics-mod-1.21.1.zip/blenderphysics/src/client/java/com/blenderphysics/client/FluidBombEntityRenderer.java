package com.blenderphysics.client;

import com.blenderphysics.entity.FluidBombEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

/**
 * Renderizador ligero y autocontenido para las granadas de fluido: un sprite billboard
 * (siempre de cara a la cámara) con la textura de la propia granada, evitando depender
 * de interfaces específicas de renderizado de ítems que varían entre versiones.
 */
public class FluidBombEntityRenderer extends EntityRenderer<FluidBombEntity> {

	private final Identifier texture;
	private static final float SIZE = 0.35f;

	public FluidBombEntityRenderer(EntityRendererFactory.Context ctx, String textureName) {
		super(ctx);
		this.texture = Identifier.of("blenderphysics", "textures/item/" + textureName + ".png");
	}

	@Override
	public Identifier getTexture(FluidBombEntity entity) {
		return texture;
	}

	@Override
	public void render(FluidBombEntity entity, float yaw, float tickDelta, MatrixStack matrices,
			VertexConsumerProvider vertexConsumers, int light) {
		matrices.push();
		matrices.multiply(this.dispatcher.getRotation());
		matrices.scale(SIZE, SIZE, SIZE);

		VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(texture));
		Matrix4f m = matrices.peek().getPositionMatrix();

		buffer.vertex(m, -0.5f, -0.5f, 0f).color(255, 255, 255, 255).texture(0f, 1f)
				.overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0, 1, 0);
		buffer.vertex(m, 0.5f, -0.5f, 0f).color(255, 255, 255, 255).texture(1f, 1f)
				.overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0, 1, 0);
		buffer.vertex(m, 0.5f, 0.5f, 0f).color(255, 255, 255, 255).texture(1f, 0f)
				.overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0, 1, 0);
		buffer.vertex(m, -0.5f, 0.5f, 0f).color(255, 255, 255, 255).texture(0f, 0f)
				.overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0, 1, 0);

		matrices.pop();
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}
