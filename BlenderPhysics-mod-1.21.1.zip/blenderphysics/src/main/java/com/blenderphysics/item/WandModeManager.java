package com.blenderphysics.item;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Guarda el modo actual de la Varita de Realismo por jugador (en memoria del servidor).
 * Se usa un mapa por UUID en vez de guardar el modo en NBT/Data Components del propio
 * ItemStack para evitar depender de APIs de serialización que cambian de forma sutil
 * entre versiones de Minecraft; el modo se mantiene mientras el jugador está conectado.
 */
public final class WandModeManager {

	private static final Map<UUID, WandMode> MODES = new ConcurrentHashMap<>();

	private WandModeManager() {
	}

	public static WandMode get(UUID playerId) {
		return MODES.getOrDefault(playerId, WandMode.CONVERSION_INDIVIDUAL);
	}

	public static WandMode cycle(UUID playerId) {
		WandMode next = get(playerId).next();
		MODES.put(playerId, next);
		return next;
	}
}
