package com.blenderphysics.item;

import com.blenderphysics.entity.PhysicsRigidBodyEntity;
import com.blenderphysics.physics.FluidType;
import com.blenderphysics.physics.PhysicsManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Varita de Realismo: la herramienta central del mod. Nunca destruye el mundo de forma
 * permanente fuera de la conversión explícita que el jugador pide, y jamás toca agua,
 * lava o slime "vanilla" salvo para leerlos y generar partículas de simulación equivalentes.
 */
public class RealityWandItem extends Item {

	private static final int FLUID_CONVERT_PARTICLES = 350;

	public RealityWandItem(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext context) {
		PlayerEntity player = context.getPlayer();
		World world = context.getWorld();
		BlockPos pos = context.getBlockPos();

		if (player != null && player.isSneaking()) {
			cycleModeAndNotify(player);
			return ActionResult.SUCCESS;
		}

		if (!(world instanceof ServerWorld serverWorld) || player == null) {
			return ActionResult.SUCCESS;
		}

		WandMode mode = WandModeManager.get(player.getUuid());
		BlockState state = world.getBlockState(pos);

		// 1) ¿Es agua/lava/slime vanilla? -> convertir en partículas de fluido realista.
		FluidType vanillaFluid = classifyVanillaFluid(state);
		if (vanillaFluid != null) {
			if (mode == WandMode.ASPIRADORA_LIMPIAR) {
				int removed = vacuumNearby(serverWorld, Vec3d.ofCenter(pos));
				player.sendMessage(Text.translatable("blenderphysics.message.vacuumed", removed), true);
			} else {
				FluidType toSpawn = mode == WandMode.GELATINA_SOFTBODY ? FluidType.SLIME : vanillaFluid;
				PhysicsManager.get().spawnBurst(serverWorld, Vec3d.ofCenter(pos), toSpawn, FLUID_CONVERT_PARTICLES, 0.8f, 0.4f);
				serverWorld.playSound(null, pos, SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1f, 1f);
			}
			return ActionResult.SUCCESS;
		}

		// 2) Bloque sólido normal -> arrancarlo y convertirlo en entidad física.
		if (!state.isAir() && !state.getCollisionShape(world, pos).isEmpty()) {
			if (mode == WandMode.EXPLOSION_3X3X3) {
				convert3x3x3(serverWorld, pos);
			} else {
				convertSingleBlock(serverWorld, pos, state);
			}
			return ActionResult.SUCCESS;
		}

		return ActionResult.PASS;
	}

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		if (user.isSneaking() && !world.isClient) {
			cycleModeAndNotify(user);
			return ActionResult.SUCCESS;
		}
		return ActionResult.PASS;
	}

	/** Invocado desde el evento de interacción con entidades para convertir ítems tirados. */
	public static ActionResult onUseOnItemEntity(PlayerEntity player, World world, ItemEntity itemEntity) {
		if (world.isClient || !(world instanceof ServerWorld serverWorld)) return ActionResult.SUCCESS;
		Vec3d pos = itemEntity.getPos();
		ItemStack stack = itemEntity.getStack().copy();
		itemEntity.discard();
		PhysicsRigidBodyEntity rigid = PhysicsRigidBodyEntity.fromItemStack(serverWorld, stack, pos);
		serverWorld.spawnEntity(rigid);
		return ActionResult.SUCCESS;
	}

	private void cycleModeAndNotify(PlayerEntity player) {
		WandMode mode = WandModeManager.cycle(player.getUuid());
		player.sendMessage(Text.translatable("blenderphysics.message.wand_mode", Text.translatable(mode.getTranslationKey())), true);
	}

	private FluidType classifyVanillaFluid(BlockState state) {
		if (state.isOf(Blocks.WATER)) return FluidType.WATER;
		if (state.isOf(Blocks.LAVA)) return FluidType.LAVA;
		if (state.getBlock() == Blocks.SLIME_BLOCK) return FluidType.SLIME;
		return null;
	}

	private void convertSingleBlock(ServerWorld world, BlockPos pos, BlockState state) {
		world.removeBlock(pos, false);
		PhysicsRigidBodyEntity entity = PhysicsRigidBodyEntity.fromBlock(world, state, Vec3d.ofCenter(pos));
		world.spawnEntity(entity);
		world.playSound(null, pos, SoundEvents.BLOCK_STONE_BREAK, SoundCategory.BLOCKS, 0.6f, 1.1f);
	}

	private void convert3x3x3(ServerWorld world, BlockPos center) {
		int budget = 27;
		for (int dx = -1; dx <= 1 && budget > 0; dx++) {
			for (int dy = -1; dy <= 1 && budget > 0; dy++) {
				for (int dz = -1; dz <= 1 && budget > 0; dz++) {
					BlockPos p = center.add(dx, dy, dz);
					BlockState s = world.getBlockState(p);
					if (!s.isAir() && !s.getCollisionShape(world, p).isEmpty() && classifyVanillaFluid(s) == null) {
						convertSingleBlock(world, p, s);
						budget--;
					}
				}
			}
		}
	}

	private int vacuumNearby(ServerWorld world, Vec3d center) {
		var sim = PhysicsManager.get().simulationFor(world);
		var buf = sim.buffer();
		int n = buf.highWaterMark();
		int removed = 0;
		for (int i = 0; i < n; i++) {
			if (!buf.active[i]) continue;
			double dx = buf.posX[i] - center.x, dy = buf.posY[i] - center.y, dz = buf.posZ[i] - center.z;
			if (dx * dx + dy * dy + dz * dz < 3.0 * 3.0) {
				buf.kill(i);
				removed++;
			}
		}
		return removed;
	}
}
