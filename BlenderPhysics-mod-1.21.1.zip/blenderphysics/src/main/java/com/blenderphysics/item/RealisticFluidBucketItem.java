package com.blenderphysics.item;

import com.blenderphysics.physics.FluidType;
import com.blenderphysics.physics.PhysicsManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Cubo de fluido realista: NO coloca un bloque de fluido vanilla. En su lugar, vierte una
 * masa de partículas de simulación SPH en el punto apuntado, exactamente con el mismo
 * motor que usa la Varita de Realismo. Esto respeta la regla de "no reemplazar el mundo
 * natural": el mundo de Minecraft no se modifica, solo se añaden partículas propias.
 * El cubo no se consume (actúa como herramienta reutilizable, igual que la varita).
 */
public class RealisticFluidBucketItem extends Item {

	private final FluidType fluidType;
	private static final int PARTICLES_PER_USE = 350;

	public RealisticFluidBucketItem(FluidType fluidType, Settings settings) {
		super(settings);
		this.fluidType = fluidType;
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext context) {
		World world = context.getWorld();
		PlayerEntity player = context.getPlayer();
		BlockPos hitPos = context.getBlockPos().offset(context.getSide());
		Vec3d pourPos = Vec3d.ofCenter(hitPos);

		if (world instanceof ServerWorld serverWorld) {
			int spawned = PhysicsManager.get().spawnBurst(serverWorld, pourPos, fluidType, PARTICLES_PER_USE, 0.6f, 0.3f);
			serverWorld.playSound(null, hitPos, fluidType == FluidType.LAVA ? SoundEvents.ITEM_BUCKET_EMPTY_LAVA
					: SoundEvents.ITEM_BUCKET_EMPTY, SoundCategory.BLOCKS, 1.0f, 1.0f);
			if (player != null && spawned == 0) {
				player.sendMessage(net.minecraft.text.Text.translatable("blenderphysics.message.particle_limit_reached"), true);
			}
		}
		return ActionResult.SUCCESS;
	}

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		// Si no se apunta a ningún bloque (p.ej. al aire o lejos), vierte frente al jugador.
		if (world instanceof ServerWorld serverWorld) {
			Vec3d look = user.getRotationVec(1.0f);
			Vec3d pourPos = user.getEyePos().add(look.multiply(1.5));
			PhysicsManager.get().spawnBurst(serverWorld, pourPos, fluidType, PARTICLES_PER_USE, 0.6f, 0f);
		}
		return ActionResult.SUCCESS;
	}

	public FluidType getFluidType() {
		return fluidType;
	}
}
