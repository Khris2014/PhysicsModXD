package com.blenderphysics.item;

import com.blenderphysics.entity.FluidBombEntity;
import com.blenderphysics.physics.FluidType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Granada de fluido lanzable, estilo bola de nieve vanilla pero con carga física. */
public class FluidBombItem extends Item {

	private final FluidType fluidType;

	public FluidBombItem(FluidType fluidType, Settings settings) {
		super(settings);
		this.fluidType = fluidType;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_SNOWBALL_THROW,
				SoundCategory.NEUTRAL, 0.5f, 0.6f / (world.getRandom().nextFloat() * 0.4f + 0.8f));

		if (!world.isClient) {
			FluidBombEntity entity = new FluidBombEntity(world, user, fluidType);
			entity.setItem(stack);
			entity.setVelocity(user, user.getPitch(), user.getYaw(), 0.0f, 1.5f, 1.0f);
			world.spawnEntity(entity);
		}

		user.incrementStat(net.minecraft.stat.Stats.USED.getOrCreateStat(this));
		if (!user.getAbilities().creativeMode) {
			stack.decrement(1);
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
