package com.blenderphysics.item;

/** Modos de la Varita de Realismo, ciclados con Shift + Click Derecho. */
public enum WandMode {
	CONVERSION_INDIVIDUAL("blenderphysics.wand_mode.individual"),
	GELATINA_SOFTBODY("blenderphysics.wand_mode.softbody"),
	EXPLOSION_3X3X3("blenderphysics.wand_mode.explosion"),
	ASPIRADORA_LIMPIAR("blenderphysics.wand_mode.vacuum");

	private final String translationKey;

	WandMode(String translationKey) {
		this.translationKey = translationKey;
	}

	public String getTranslationKey() {
		return translationKey;
	}

	public WandMode next() {
		WandMode[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}
}
