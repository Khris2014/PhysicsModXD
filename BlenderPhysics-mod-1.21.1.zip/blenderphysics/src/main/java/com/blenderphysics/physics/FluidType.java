package com.blenderphysics.physics;

/**
 * Los tres fluidos simulados por el motor SPH. Cada uno define sus propias constantes
 * físicas (rigidez de presión, viscosidad base, color de absorción, etc.).
 * Estos NUNCA reemplazan al agua/lava/slime vanilla: son partículas de simulación propias
 * creadas por la Varita de Realismo, cubos, bombas o bloques emisores.
 */
public enum FluidType {
	WATER(998.0f, 3000.0f, 7, 0.35f, false),
	LAVA(3100.0f, 9000.0f, 7, 3.5f, true),
	SLIME(1100.0f, 1500.0f, 7, 1.8f, false);

	/** Densidad de reposo (kg/m^3, escalado a unidades de juego). */
	public final float restDensity;
	/** Rigidez de la ecuación de estado de Tait (cuanto más alto, más incompresible). */
	public final float stiffness;
	/** Exponente de la ecuación de estado de Tait. */
	public final int gamma;
	/** Viscosidad dinámica por defecto (puede ser sobreescrita en vivo por la config). */
	public final float baseViscosity;
	/** Si es true, emite luz máxima y puede incendiar/dañar entidades. */
	public final boolean incandescent;

	FluidType(float restDensity, float stiffness, int gamma, float baseViscosity, boolean incandescent) {
		this.restDensity = restDensity;
		this.stiffness = stiffness;
		this.gamma = gamma;
		this.baseViscosity = baseViscosity;
		this.incandescent = incandescent;
	}

	public static FluidType byId(int id) {
		FluidType[] values = values();
		return values[Math.floorMod(id, values.length)];
	}
}
