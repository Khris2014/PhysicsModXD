package com.blenderphysics.physics;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.tag.BlockTags;

/**
 * Densidad relativa aproximada de materiales, usada para la flotabilidad de Arquímedes
 * de los bloques convertidos por la Varita de Realismo. Densidad de referencia del agua
 * realista = 1.0: por debajo de 1.0 el objeto flota, por encima se hunde.
 */
public final class BlockDensityTable {

	private BlockDensityTable() {
	}

	public static float densityOf(BlockState state) {
		Block block = state.getBlock();
		if (state.isIn(BlockTags.LOGS) || state.isIn(BlockTags.PLANKS) || state.isIn(BlockTags.WOODEN_SLABS)
				|| state.isIn(BlockTags.WOODEN_STAIRS) || state.isIn(BlockTags.WOODEN_FENCES)
				|| state.isIn(BlockTags.LEAVES) || state.isIn(BlockTags.WOOL)) {
			return 0.55f;
		}
		if (state.isIn(BlockTags.ICE)) {
			return 0.90f;
		}
		if (state.isIn(BlockTags.BASE_STONE_OVERWORLD) || state.isIn(BlockTags.STONE_BRICKS)) {
			return 2.6f;
		}
		String path = net.minecraft.registry.Registries.BLOCK.getId(block).getPath();
		if (path.contains("iron") || path.contains("gold") || path.contains("copper")
				|| path.contains("netherite") || path.contains("obsidian") || path.contains("anvil")
				|| path.contains("lead") || path.contains("heavy")) {
			return 7.0f; // metales/obsidiana: se hunden con fuerza
		}
		// valor por defecto razonable para el resto de bloques sólidos (ladrillo, tierra, arena...)
		return 1.8f;
	}
}
