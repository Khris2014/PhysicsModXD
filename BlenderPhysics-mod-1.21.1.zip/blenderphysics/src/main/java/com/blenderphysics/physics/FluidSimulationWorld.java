package com.blenderphysics.physics;

import com.blenderphysics.config.BlenderPhysicsConfig;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Contiene toda la simulación de fluidos realistas de UN ServerWorld (una dimensión):
 * el buffer de partículas, el solver SPH y la lógica de interacción agua-lava (vapor +
 * solidificación) y drenajes. Pensado para funcionar sin modificar jamás un bloque de
 * agua/lava/slime vanilla: solo las partículas propias del mod.
 */
public final class FluidSimulationWorld {

	private final ServerWorld world;
	private final long worldKey;
	private FluidParticleBuffer buffer;
	private SPHSolver solver;
	private final List<DrainPoint> drains = new ArrayList<>();

	public FluidSimulationWorld(ServerWorld world) {
		this.world = world;
		this.worldKey = world.getRegistryKey().getValue().toString().hashCode();
		int cap = BlenderPhysicsConfig.get().maxParticles;
		this.buffer = new FluidParticleBuffer(cap);
		this.solver = new SPHSolver(cap);
	}

	public long worldKey() {
		return worldKey;
	}

	public FluidParticleBuffer buffer() {
		return buffer;
	}

	public ServerWorld world() {
		return world;
	}

	/** Reconstruye buffer/solver si el límite de partículas cambió en vivo en la GUI. */
	public void applyConfigIfChanged(int newCapacityHint) {
		if (newCapacityHint > buffer.capacity()) {
			FluidParticleBuffer newBuf = new FluidParticleBuffer(newCapacityHint);
			// migración simple: las partículas activas existentes se re-crean (el sistema se
			// repuebla de forma natural en 1-2 segundos; evita copias complejas de estado SoA)
			this.buffer = newBuf;
			this.solver = new SPHSolver(newCapacityHint);
		}
	}

	public int spawnBurst(Vec3d center, FluidType type, int count, float spread, float upwardBias) {
		BlenderPhysicsConfig cfg = BlenderPhysicsConfig.get();
		int budget = cfg.maxParticles - buffer.activeCount();
		int toSpawn = Math.min(count, Math.max(0, budget));
		for (int i = 0; i < toSpawn; i++) {
			double ox = (world.random.nextDouble() - 0.5) * spread;
			double oy = world.random.nextDouble() * spread * 0.5 + upwardBias;
			double oz = (world.random.nextDouble() - 0.5) * spread;
			int idx = buffer.spawn((float) (center.x + ox), (float) (center.y + oy), (float) (center.z + oz), type, worldKey);
			if (type == FluidType.SLIME) {
				buffer.groupId[idx] = (int) (center.x * 73856093 ^ (int) center.y * 19349663 ^ (int) center.z * 83492791);
			}
		}
		return toSpawn;
	}

	public void registerDrain(BlockPos pos) {
		drains.add(new DrainPoint(pos));
	}

	public void unregisterDrain(BlockPos pos) {
		drains.removeIf(d -> d.pos.equals(pos));
	}

	/** Avanza la simulación aplicando {@code substeps} sub-pasos de duración 1/20/substeps segundos. */
	public void tick() {
		BlenderPhysicsConfig cfg = BlenderPhysicsConfig.get();
		float dt = (1f / 20f) / cfg.physicsSubsteps;
		for (int s = 0; s < cfg.physicsSubsteps; s++) {
			solver.step(buffer, world, worldKey, dt);
		}
		handleLavaWaterInteraction();
		handleDrains();
	}

	/**
	 * Agua + Lava realistas en contacto -> vapor, chisporroteo y solidificación en Obsidiana/Adoquín.
	 * Usa la rejilla espacial del solver (ya reconstruida en el último sub-paso) en vez de una
	 * búsqueda O(n^2), por lo que escala bien incluso con miles de partículas activas.
	 */
	private void handleLavaWaterInteraction() {
		int n = buffer.highWaterMark();
		float mergeDistSq = 0.3f * 0.3f;
		SpatialHashGrid3D grid = solver.grid();
		for (int i = 0; i < n; i++) {
			if (!buffer.active[i] || buffer.worldSeed[i] != worldKey) continue;
			if (FluidType.byId(buffer.type[i]) != FluidType.LAVA) continue;
			float lx = buffer.posX[i], ly = buffer.posY[i], lz = buffer.posZ[i];
			final int lavaIdx = i;
			final int[] waterMatch = {-1};
			grid.forEachNeighbor(lx, ly, lz, j -> {
				if (waterMatch[0] != -1 || j == lavaIdx) return;
				if (!buffer.active[j] || buffer.worldSeed[j] != worldKey) return;
				if (FluidType.byId(buffer.type[j]) != FluidType.WATER) return;
				float dx = lx - buffer.posX[j];
				float dy = ly - buffer.posY[j];
				float dz = lz - buffer.posZ[j];
				if (dx * dx + dy * dy + dz * dz <= mergeDistSq) {
					waterMatch[0] = j;
				}
			});
			if (waterMatch[0] != -1) {
				spawnSteamEffect(lx, ly, lz);
				boolean fastFlow = Math.abs(buffer.velY[i]) > 0.3f || Math.abs(buffer.velX[i]) > 0.3f;
				BlockPos pos = BlockPos.ofFloored(lx, ly, lz);
				if (world.getBlockState(pos).isAir()) {
					world.setBlockState(pos, (fastFlow ? Blocks.COBBLESTONE : Blocks.OBSIDIAN).getDefaultState());
				}
				buffer.kill(i);
				buffer.kill(waterMatch[0]);
			}
		}
	}

	private void spawnSteamEffect(float x, float y, float z) {
		world.spawnParticles(ParticleTypes.CLOUD, x, y + 0.2, z, 3, 0.1, 0.1, 0.1, 0.01);
		world.playSound(null, BlockPos.ofFloored(x, y, z), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.5f,
				1.4f + world.random.nextFloat() * 0.3f);
	}

	private void handleDrains() {
		if (drains.isEmpty()) return;
		int n = buffer.highWaterMark();
		for (DrainPoint drain : drains) {
			double cx = drain.pos.getX() + 0.5, cy = drain.pos.getY() + 0.6, cz = drain.pos.getZ() + 0.5;
			for (int i = 0; i < n; i++) {
				if (!buffer.active[i] || buffer.worldSeed[i] != worldKey) continue;
				double dx = buffer.posX[i] - cx, dy = buffer.posY[i] - cy, dz = buffer.posZ[i] - cz;
				if (dx * dx + dy * dy + dz * dz < 0.6 * 0.6) {
					buffer.kill(i);
				}
			}
		}
	}

	public void clearAll() {
		buffer.killAll();
	}

	private record DrainPoint(BlockPos pos) {
	}
}
