package com.blenderphysics.physics;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Punto de entrada único del motor de físicas: mantiene una {@link FluidSimulationWorld}
 * por dimensión (ServerWorld) y se engancha al tick del servidor mediante
 * {@code ServerTickEvents.END_SERVER_TICK} (ver {@link com.blenderphysics.BlenderPhysicsMod}).
 */
public final class PhysicsManager {

	private static final PhysicsManager INSTANCE = new PhysicsManager();

	private final Map<ServerWorld, FluidSimulationWorld> worlds = new ConcurrentHashMap<>();

	private PhysicsManager() {
	}

	public static PhysicsManager get() {
		return INSTANCE;
	}

	public FluidSimulationWorld simulationFor(ServerWorld world) {
		return worlds.computeIfAbsent(world, FluidSimulationWorld::new);
	}

	public void tickAll() {
		for (FluidSimulationWorld sim : worlds.values()) {
			sim.tick();
		}
	}

	public void clearAll() {
		for (FluidSimulationWorld sim : worlds.values()) {
			sim.clearAll();
		}
	}

	public int spawnBurst(ServerWorld world, Vec3d pos, FluidType type, int count, float spread, float upwardBias) {
		return simulationFor(world).spawnBurst(pos, type, count, spread, upwardBias);
	}

	public void onServerStopping() {
		worlds.clear();
		PhysicsThreadPool.get().shutdown();
	}
}
