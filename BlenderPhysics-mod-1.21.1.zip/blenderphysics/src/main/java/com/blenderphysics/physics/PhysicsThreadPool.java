package com.blenderphysics.physics;

import com.blenderphysics.BlenderPhysicsMod;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pool de hilos trabajadores dedicado exclusivamente a la simulación física, totalmente
 * separado del hilo principal del servidor/cliente. Cada fase del solver SPH (densidad,
 * fuerzas, integración) se reparte en bloques contiguos de índices de partícula entre los
 * hilos disponibles; como cada partícula solo escribe en su propio slot del SoA, no hace
 * falta ningún lock: es "embarazosamente paralelo".
 */
public final class PhysicsThreadPool {

	private static final PhysicsThreadPool INSTANCE = new PhysicsThreadPool();

	private final ExecutorService executor;
	private final int workerCount;

	private PhysicsThreadPool() {
		int cores = Runtime.getRuntime().availableProcessors();
		this.workerCount = Math.max(1, cores - 1); // deja un núcleo libre para el tick principal
		AtomicInteger threadIndex = new AtomicInteger(0);
		ThreadFactory factory = r -> {
			Thread t = new Thread(r, "BlenderPhysics-Worker-" + threadIndex.getAndIncrement());
			t.setDaemon(true);
			t.setPriority(Thread.NORM_PRIORITY - 1);
			return t;
		};
		this.executor = Executors.newFixedThreadPool(workerCount, factory);
		BlenderPhysicsMod.LOGGER.info("BlenderPhysics: pool de físicas iniciado con {} hilos trabajadores.", workerCount);
	}

	public static PhysicsThreadPool get() {
		return INSTANCE;
	}

	public int workerCount() {
		return workerCount;
	}

	/**
	 * Ejecuta {@code task} en paralelo sobre el rango [0, count) repartido en bloques
	 * contiguos entre los hilos del pool, y bloquea hasta que todos terminan.
	 * No se genera basura adicional salvo el propio CountDownLatch (objeto ligero y
	 * de vida muy corta, recolectado en la generación joven sin impacto perceptible).
	 */
	public void parallelFor(int count, RangeTask task) {
		if (count <= 0) return;
		int chunks = Math.min(workerCount, Math.max(1, count));
		int chunkSize = (count + chunks - 1) / chunks;
		CountDownLatch latch = new CountDownLatch(chunks);
		for (int c = 0; c < chunks; c++) {
			final int start = c * chunkSize;
			final int end = Math.min(count, start + chunkSize);
			if (start >= end) {
				latch.countDown();
				continue;
			}
			executor.execute(() -> {
				try {
					task.run(start, end);
				} catch (Throwable t) {
					BlenderPhysicsMod.LOGGER.error("Error en hilo de físicas BlenderPhysics", t);
				} finally {
					latch.countDown();
				}
			});
		}
		try {
			latch.await();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public void shutdown() {
		executor.shutdownNow();
	}

	@FunctionalInterface
	public interface RangeTask {
		void run(int startInclusive, int endExclusive);
	}
}
