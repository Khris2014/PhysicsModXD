package com.blenderphysics.physics;

import com.blenderphysics.config.BlenderPhysicsConfig;
import net.minecraft.world.World;

/**
 * Solver de Hidrodinámica de Partículas Suavizadas (SPH) para los tres fluidos del mod.
 * Usa los kernels estándar de Müller et al. 2003 ("Particle-Based Fluid Simulation for
 * Interactive Applications"): Poly6 para densidad, Spiky para el gradiente de presión y
 * Viscosity-Laplacian para la difusión viscosa. Todo el trabajo pesado se reparte en el
 * {@link PhysicsThreadPool}, cada partícula escribe exclusivamente en su propio slot.
 *
 * El slime añade un segundo sistema (masa-resorte) ejecutado tras el SPH para dar
 * "memoria de forma": cada partícula de slime es atraída suavemente hacia su posición de
 * reposo relativa dentro del cuerpo (shapeAnchor), lo que lo hace temblar como gelatina y
 * recuperar su forma tras un impacto, sin perder el comportamiento fluido del SPH.
 */
public final class SPHSolver {

	private static final float SMOOTHING_RADIUS = 0.45f; // h, en bloques
	private static final float H2 = SMOOTHING_RADIUS * SMOOTHING_RADIUS;
	private static final float PARTICLE_MASS = 1.0f;

	// Constantes de los kernels (precalculadas para H = SMOOTHING_RADIUS)
	private static final float POLY6 = (float) (315.0 / (64.0 * Math.PI * Math.pow(SMOOTHING_RADIUS, 9)));
	private static final float SPIKY_GRAD = (float) (-45.0 / (Math.PI * Math.pow(SMOOTHING_RADIUS, 6)));
	private static final float VISC_LAP = (float) (45.0 / (Math.PI * Math.pow(SMOOTHING_RADIUS, 6)));

	private final SpatialHashGrid3D grid;

	public SPHSolver(int expectedParticles) {
		this.grid = new SpatialHashGrid3D(SMOOTHING_RADIUS, expectedParticles);
	}

	/**
	 * Avanza la simulación un sub-paso de duración {@code dt} para todas las partículas
	 * activas del mundo dado (filtradas por worldKey para que varias dimensiones puedan
	 * compartir el mismo buffer sin interferir entre sí).
	 */
	public void step(FluidParticleBuffer buf, World world, long worldKey, float dt) {
		int n = buf.highWaterMark();
		if (n == 0) return;

		grid.rebuild(buf);
		BlenderPhysicsConfig cfg = BlenderPhysicsConfig.get();
		PhysicsThreadPool pool = PhysicsThreadPool.get();

		// Fase 1: densidad + presión (lectura de vecinos, escritura solo en el propio índice)
		pool.parallelFor(n, (start, end) -> computeDensityPressure(buf, worldKey, start, end));

		// Fase 2: fuerzas (presión + viscosidad + gravedad) -> acumuladas en acc*
		pool.parallelFor(n, (start, end) -> computeForces(buf, worldKey, cfg, start, end));

		// Fase 3: memoria de forma del slime (masa-resorte hacia el ancla relativa del cuerpo)
		pool.parallelFor(n, (start, end) -> applySlimeShapeMemory(buf, start, end));

		// Fase 4: integración semi-implícita (Euler simpléctico) + colisión contra VoxelShape.
		// La colisión toca el mundo (no thread-safe en general para todas las versiones de MC),
		// así que se ejecuta en el hilo que llamó a step() tras recoger los resultados paralelos.
		integrateAndCollide(buf, world, worldKey, dt);
	}

	private void computeDensityPressure(FluidParticleBuffer buf, long worldKey, int start, int end) {
		for (int i = start; i < end; i++) {
			if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;
			FluidType t = FluidType.byId(buf.type[i]);
			final float[] densityAccum = {0f};
			float xi = buf.posX[i], yi = buf.posY[i], zi = buf.posZ[i];
			grid.forEachNeighbor(xi, yi, zi, j -> {
				if (!buf.active[j] || buf.worldSeed[j] != worldKey) return;
				float dx = xi - buf.posX[j];
				float dy = yi - buf.posY[j];
				float dz = zi - buf.posZ[j];
				float r2 = dx * dx + dy * dy + dz * dz;
				if (r2 < H2) {
					float diff = H2 - r2;
					densityAccum[0] += PARTICLE_MASS * POLY6 * diff * diff * diff;
				}
			});
			float density = Math.max(densityAccum[0], 1e-4f);
			buf.density[i] = density;
			float ratio = density / t.restDensity;
			float pow = ratio;
			for (int p = 1; p < t.gamma; p++) pow *= ratio; // ratio^gamma
			buf.pressure[i] = Math.max(0f, t.stiffness * (pow - 1f));
		}
	}

	private void computeForces(FluidParticleBuffer buf, long worldKey, BlenderPhysicsConfig cfg, int start, int end) {
		float gravity = -0.30f * cfg.gravity; // escala a unidades de bloque/tick^2
		for (int i = start; i < end; i++) {
			if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;
			FluidType t = FluidType.byId(buf.type[i]);
			float viscosity = switch (t) {
				case WATER -> cfg.waterViscosity;
				case LAVA -> cfg.lavaViscosity;
				case SLIME -> cfg.slimeViscosity;
			};

			float xi = buf.posX[i], yi = buf.posY[i], zi = buf.posZ[i];
			float vxi = buf.velX[i], vyi = buf.velY[i], vzi = buf.velZ[i];
			float pi = buf.pressure[i], rhoi = buf.density[i];

			final float[] fPressure = {0f, 0f, 0f};
			final float[] fViscosity = {0f, 0f, 0f};

			grid.forEachNeighbor(xi, yi, zi, j -> {
				if (j == i || !buf.active[j] || buf.worldSeed[j] != worldKey) return;
				float dx = xi - buf.posX[j];
				float dy = yi - buf.posY[j];
				float dz = zi - buf.posZ[j];
				float r2 = dx * dx + dy * dy + dz * dz;
				if (r2 >= H2 || r2 < 1e-8f) return;
				float r = (float) Math.sqrt(r2);
				float rhoj = Math.max(buf.density[j], 1e-4f);

				// Fuerza de presión (kernel Spiky), simetrizada
				float hr = SMOOTHING_RADIUS - r;
				float pressTerm = PARTICLE_MASS * (pi + buf.pressure[j]) / (2f * rhoj) * SPIKY_GRAD * hr * hr;
				fPressure[0] += -dx / r * pressTerm;
				fPressure[1] += -dy / r * pressTerm;
				fPressure[2] += -dz / r * pressTerm;

				// Fuerza de viscosidad (laplaciano), suaviza diferencias de velocidad entre vecinos
				float viscTerm = PARTICLE_MASS * VISC_LAP * hr / rhoj;
				fViscosity[0] += (buf.velX[j] - vxi) * viscTerm;
				fViscosity[1] += (buf.velY[j] - vyi) * viscTerm;
				fViscosity[2] += (buf.velZ[j] - vzi) * viscTerm;
			});

			float invRho = 1f / Math.max(rhoi, 1e-4f);
			buf.accX[i] = fPressure[0] * invRho + fViscosity[0] * viscosity * invRho;
			buf.accY[i] = fPressure[1] * invRho + fViscosity[1] * viscosity * invRho + gravity;
			buf.accZ[i] = fPressure[2] * invRho + fViscosity[2] * viscosity * invRho;
		}
	}

	private void applySlimeShapeMemory(FluidParticleBuffer buf, int start, int end) {
		final float springK = 2.2f;
		for (int i = start; i < end; i++) {
			if (!buf.active[i] || FluidType.byId(buf.type[i]) != FluidType.SLIME) continue;
			if (buf.groupId[i] < 0) continue;
			float dx = buf.shapeAnchorX[i] - buf.posX[i];
			float dy = buf.shapeAnchorY[i] - buf.posY[i];
			float dz = buf.shapeAnchorZ[i] - buf.posZ[i];
			buf.accX[i] += dx * springK;
			buf.accY[i] += dy * springK;
			buf.accZ[i] += dz * springK;
		}
	}

	private void integrateAndCollide(FluidParticleBuffer buf, World world, long worldKey, float dt) {
		int n = buf.highWaterMark();
		for (int i = 0; i < n; i++) {
			if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;

			buf.velX[i] += buf.accX[i] * dt;
			buf.velY[i] += buf.accY[i] * dt;
			buf.velZ[i] += buf.accZ[i] * dt;

			// amortiguación numérica ligera para estabilidad a bajo sub-step-count
			buf.velX[i] *= 0.996f;
			buf.velY[i] *= 0.999f;
			buf.velZ[i] *= 0.996f;

			float nx = buf.posX[i] + buf.velX[i] * dt;
			float ny = buf.posY[i] + buf.velY[i] * dt;
			float nz = buf.posZ[i] + buf.velZ[i] * dt;

			BlockCollisionUtil.CollisionResult res =
					BlockCollisionUtil.resolve(world, nx, ny, nz, buf.velX[i], buf.velY[i], buf.velZ[i]);

			buf.posX[i] = res.x();
			buf.posY[i] = res.y();
			buf.posZ[i] = res.z();
			buf.velX[i] = res.vx();
			buf.velY[i] = res.vy();
			buf.velZ[i] = res.vz();
		}
	}

	public SpatialHashGrid3D grid() {
		return grid;
	}
}
