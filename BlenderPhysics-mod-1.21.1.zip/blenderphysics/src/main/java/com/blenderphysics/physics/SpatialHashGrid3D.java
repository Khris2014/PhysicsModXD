package com.blenderphysics.physics;

/**
 * Rejilla de dispersión espacial (spatial hash grid) en 3D, construida con "counting sort"
 * sobre arreglos primitivos. Permite búsqueda de vecinos en O(1) amortizado sin generar
 * basura de memoria después del "warm-up" inicial (los arreglos se reutilizan y solo
 * crecen si hace falta más capacidad).
 *
 * Algoritmo (idéntico al usado en motores SPH de producción):
 *  1. cellOf(i)      -> hash de celda para cada partícula activa.
 *  2. cellCount[]    -> histograma de partículas por celda.
 *  3. cellStart[]    -> suma prefija (offset de inicio de cada celda dentro de 'sorted').
 *  4. sorted[]       -> índices de partícula ordenados por celda (counting sort estable).
 * Consultar los vecinos de una celda es entonces un simple slice [cellStart[c], cellStart[c+1]).
 */
public final class SpatialHashGrid3D {

	private final float cellSize;
	private final float invCellSize;
	private int hashTableSize;

	private int[] cellCount;
	private int[] cellStart;
	private int[] sorted;
	private int[] particleCellIndex; // cache: celda (hash) de cada partícula, por índice de partícula

	public SpatialHashGrid3D(float cellSize, int expectedParticles) {
		this.cellSize = cellSize;
		this.invCellSize = 1.0f / cellSize;
		this.hashTableSize = nextPowerOfTwo(Math.max(1024, expectedParticles * 2));
		allocate(expectedParticles);
	}

	private void allocate(int particleCapacity) {
		cellCount = new int[hashTableSize + 1];
		cellStart = new int[hashTableSize + 1];
		sorted = new int[Math.max(1, particleCapacity)];
		particleCellIndex = new int[Math.max(1, particleCapacity)];
	}

	private static int nextPowerOfTwo(int v) {
		int p = 1;
		while (p < v) p <<= 1;
		return p;
	}

	private int hashCell(int cx, int cy, int cz) {
		// hash espacial clásico (primos grandes) + máscara de potencia de dos
		int h = (cx * 73856093) ^ (cy * 19349663) ^ (cz * 83492791);
		return h & (hashTableSize - 1);
	}

	public int cellOf(float x, float y, float z) {
		int cx = (int) Math.floor(x * invCellSize);
		int cy = (int) Math.floor(y * invCellSize);
		int cz = (int) Math.floor(z * invCellSize);
		return hashCell(cx, cy, cz);
	}

	/**
	 * Reconstruye la rejilla para el rango [0, highWaterMark) del buffer, ignorando
	 * partículas inactivas. Debe llamarse una vez por sub-paso de simulación.
	 */
	public void rebuild(FluidParticleBuffer buf) {
		int n = buf.highWaterMark();
		if (sorted.length < n) {
			sorted = new int[n];
			particleCellIndex = new int[n];
		}
		java.util.Arrays.fill(cellCount, 0);

		for (int i = 0; i < n; i++) {
			if (!buf.active[i]) {
				particleCellIndex[i] = -1;
				continue;
			}
			int c = cellOf(buf.posX[i], buf.posY[i], buf.posZ[i]);
			particleCellIndex[i] = c;
			cellCount[c]++;
		}

		// suma prefija -> cellStart
		int running = 0;
		for (int c = 0; c < hashTableSize; c++) {
			cellStart[c] = running;
			running += cellCount[c];
		}
		cellStart[hashTableSize] = running;

		// counting sort estable usando un cursor temporal por celda
		int[] cursor = cellStart.clone();
		for (int i = 0; i < n; i++) {
			int c = particleCellIndex[i];
			if (c < 0) continue;
			sorted[cursor[c]++] = i;
		}
	}

	/**
	 * Visita todas las partículas en la celda que contiene (x,y,z) y en las 26 celdas
	 * vecinas (bloque 3x3x3), invocando {@code visitor} para cada índice de partícula.
	 * No genera basura: usa una interfaz funcional primitiva implementada por el llamador.
	 */
	// Nota: al igual que en "Optimized Spatial Hashing for Collision Detection" (Teschner et al.),
	// usamos una tabla de hash en vez de una rejilla densa para no desperdiciar memoria en mundos
	// grandes/dispersos. Con una tabla suficientemente grande (hashTableSize >= 2x partículas
	// esperadas) las colisiones de hash entre las 27 celdas vecinas consultadas son estadísticamente
	// raras y su efecto (doble conteo ocasional) es imperceptible en la simulación de fluidos.
	public void forEachNeighbor(float x, float y, float z, NeighborVisitor visitor) {
		int cx = (int) Math.floor(x * invCellSize);
		int cy = (int) Math.floor(y * invCellSize);
		int cz = (int) Math.floor(z * invCellSize);
		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					int c = hashCell(cx + dx, cy + dy, cz + dz);
					int start = cellStart[c];
					int end = cellStart[c + 1];
					for (int k = start; k < end; k++) {
						visitor.visit(sorted[k]);
					}
				}
			}
		}
	}

	@FunctionalInterface
	public interface NeighborVisitor {
		void visit(int particleIndex);
	}

	public float cellSize() {
		return cellSize;
	}
}
