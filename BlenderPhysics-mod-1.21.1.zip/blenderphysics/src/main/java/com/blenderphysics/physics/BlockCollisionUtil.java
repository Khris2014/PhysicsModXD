package com.blenderphysics.physics;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;

import java.util.List;

/**
 * Resolución de colisión de una partícula de fluido (tratada como una micro-esfera/AABB)
 * contra la geometría exacta del mundo (VoxelShape), consultando las mismas cajas de
 * colisión que usa el motor vanilla. Esto permite que los fluidos se deslicen por
 * escaleras, pasen bajo losas, choquen contra vallas/cristales/puertas y se acumulen
 * dentro de calderos, en vez de tratar cada bloque como un cubo sólido genérico.
 */
public final class BlockCollisionUtil {

	private BlockCollisionUtil() {
	}

	private static final float PARTICLE_RADIUS = 0.06f;

	/**
	 * Intenta resolver la posición (x,y,z) contra los bloques sólidos cercanos.
	 * Devuelve true si hubo colisión y modifica outVel (reduciendo/anulando la componente
	 * de velocidad que apuntaba contra la superficie) a través de outVelDelta.
	 */
	public static CollisionResult resolve(World world, float x, float y, float z, float vx, float vy, float vz) {
		int minX = (int) Math.floor(x - PARTICLE_RADIUS);
		int maxX = (int) Math.floor(x + PARTICLE_RADIUS);
		int minY = (int) Math.floor(y - PARTICLE_RADIUS);
		int maxY = (int) Math.floor(y + PARTICLE_RADIUS);
		int minZ = (int) Math.floor(z - PARTICLE_RADIUS);
		int maxZ = (int) Math.floor(z + PARTICLE_RADIUS);

		float px = x, py = y, pz = z;
		float nvx = vx, nvy = vy, nvz = vz;
		boolean collided = false;

		BlockPos.Mutable mpos = new BlockPos.Mutable();
		for (int bx = minX; bx <= maxX; bx++) {
			for (int by = minY; by <= maxY; by++) {
				for (int bz = minZ; bz <= maxZ; bz++) {
					mpos.set(bx, by, bz);
					BlockState state = world.getBlockState(mpos);
					if (state.isAir()) continue;
					VoxelShape shape = state.getCollisionShape(world, mpos);
					if (shape.isEmpty()) continue; // no colisiona: carteles, flores, puertas abiertas, etc.

					List<Box> boxes = shape.getBoundingBoxes();
					for (Box local : boxes) {
						Box world_ = local.offset(bx, by, bz);
						if (!world_.contains(px, py, pz) &&
								!(px + PARTICLE_RADIUS > world_.minX && px - PARTICLE_RADIUS < world_.maxX &&
										py + PARTICLE_RADIUS > world_.minY && py - PARTICLE_RADIUS < world_.maxY &&
										pz + PARTICLE_RADIUS > world_.minZ && pz - PARTICLE_RADIUS < world_.maxZ)) {
							continue;
						}

						// penetración mínima en cada eje: empuja por el eje de menor solapamiento (resolución tipo AABB)
						float overlapMinX = (float) (world_.maxX + PARTICLE_RADIUS) - px;
						float overlapMaxX = px - (float) (world_.minX - PARTICLE_RADIUS);
						float overlapMinY = (float) (world_.maxY + PARTICLE_RADIUS) - py;
						float overlapMaxY = py - (float) (world_.minY - PARTICLE_RADIUS);
						float overlapMinZ = (float) (world_.maxZ + PARTICLE_RADIUS) - pz;
						float overlapMaxZ = pz - (float) (world_.minZ - PARTICLE_RADIUS);

						float pushX = overlapMinX < overlapMaxX ? overlapMinX : -overlapMaxX;
						float pushY = overlapMinY < overlapMaxY ? overlapMinY : -overlapMaxY;
						float pushZ = overlapMinZ < overlapMaxZ ? overlapMinZ : -overlapMaxZ;

						float absX = Math.abs(pushX), absY = Math.abs(pushY), absZ = Math.abs(pushZ);
						if (absX <= absY && absX <= absZ) {
							px += pushX;
							nvx *= -0.15f; // pequeño rebote amortiguado
						} else if (absY <= absX && absY <= absZ) {
							py += pushY;
							nvy = pushY > 0 ? Math.max(0, nvy) : Math.min(0, nvy);
							if (pushY > 0) nvy = 0; // asentado sobre superficie sólida
						} else {
							pz += pushZ;
							nvz *= -0.15f;
						}
						collided = true;
					}
				}
			}
		}

		return new CollisionResult(px, py, pz, nvx, nvy, nvz, collided);
	}

	public record CollisionResult(float x, float y, float z, float vx, float vy, float vz, boolean collided) {
	}
}
