package com.blenderphysics.physics;

import java.util.Arrays;

/**
 * Almacén de partículas en "Structure of Arrays" (SoA) usando únicamente arreglos
 * primitivos. Esto evita generar basura de memoria (sin objetos por partícula, sin boxing),
 * lo que elimina los picos del Garbage Collector incluso con miles de partículas activas.
 *
 * El buffer se redimensiona (crece) solo cuando hace falta y nunca durante el hot-path
 * de simulación normal; las partículas "muertas" simplemente se marcan inactivas y sus
 * huecos se reciclan mediante una pila de índices libres.
 */
public final class FluidParticleBuffer {

	public float[] posX, posY, posZ;
	public float[] velX, velY, velZ;
	public float[] accX, accY, accZ;
	public float[] density, pressure;
	public byte[] type;          // FluidType ordinal
	public boolean[] active;
	public int[] groupId;        // usado por slime (mass-spring) para enlazar partículas del mismo cuerpo
	public float[] shapeAnchorX, shapeAnchorY, shapeAnchorZ; // posición de reposo relativa (memoria de forma del slime)
	public long[] worldSeed;     // identificador compacto del mundo/dimensión al que pertenece la partícula

	private int capacity;
	private int count;
	private final int[] freeStack;
	private int freeTop;

	public FluidParticleBuffer(int initialCapacity) {
		this.capacity = Math.max(64, initialCapacity);
		allocate(capacity);
		this.freeStack = new int[this.capacity];
		for (int i = 0; i < this.capacity; i++) {
			freeStack[i] = this.capacity - 1 - i;
		}
		this.freeTop = this.capacity;
	}

	private void allocate(int cap) {
		posX = new float[cap]; posY = new float[cap]; posZ = new float[cap];
		velX = new float[cap]; velY = new float[cap]; velZ = new float[cap];
		accX = new float[cap]; accY = new float[cap]; accZ = new float[cap];
		density = new float[cap]; pressure = new float[cap];
		type = new byte[cap];
		active = new boolean[cap];
		groupId = new int[cap];
		shapeAnchorX = new float[cap]; shapeAnchorY = new float[cap]; shapeAnchorZ = new float[cap];
		worldSeed = new long[cap];
	}

	/** Capacidad máxima actual (puede crecer). */
	public int capacity() {
		return capacity;
	}

	/** Índice más alto usado + 1 (para iterar de forma compacta). */
	public int highWaterMark() {
		return count;
	}

	public int activeCount() {
		int c = 0;
		for (int i = 0; i < count; i++) if (active[i]) c++;
		return c;
	}

	/**
	 * Reserva un slot de partícula y devuelve su índice, o -1 si se alcanzó el límite
	 * configurado por {@code maxParticles} (el llamador debe comprobar ese límite antes).
	 */
	public int spawn(float x, float y, float z, FluidType t, long worldKey) {
		int idx;
		if (freeTop > 0) {
			idx = freeStack[--freeTop];
		} else {
			if (count >= capacity) {
				growTo(capacity * 2);
			}
			idx = count++;
		}
		posX[idx] = x; posY[idx] = y; posZ[idx] = z;
		velX[idx] = 0; velY[idx] = 0; velZ[idx] = 0;
		accX[idx] = 0; accY[idx] = 0; accZ[idx] = 0;
		density[idx] = 0; pressure[idx] = 0;
		type[idx] = (byte) t.ordinal();
		active[idx] = true;
		groupId[idx] = -1;
		shapeAnchorX[idx] = x; shapeAnchorY[idx] = y; shapeAnchorZ[idx] = z;
		worldSeed[idx] = worldKey;
		return idx;
	}

	public void kill(int idx) {
		if (idx < 0 || idx >= count || !active[idx]) return;
		active[idx] = false;
		if (freeTop < freeStack.length) {
			freeStack[freeTop++] = idx;
		}
	}

	public void killAll() {
		Arrays.fill(active, 0, count, false);
		freeTop = 0;
		for (int i = 0; i < count; i++) {
			if (freeTop < freeStack.length) freeStack[freeTop++] = i;
		}
	}

	private void growTo(int newCap) {
		posX = Arrays.copyOf(posX, newCap); posY = Arrays.copyOf(posY, newCap); posZ = Arrays.copyOf(posZ, newCap);
		velX = Arrays.copyOf(velX, newCap); velY = Arrays.copyOf(velY, newCap); velZ = Arrays.copyOf(velZ, newCap);
		accX = Arrays.copyOf(accX, newCap); accY = Arrays.copyOf(accY, newCap); accZ = Arrays.copyOf(accZ, newCap);
		density = Arrays.copyOf(density, newCap); pressure = Arrays.copyOf(pressure, newCap);
		type = Arrays.copyOf(type, newCap);
		active = Arrays.copyOf(active, newCap);
		groupId = Arrays.copyOf(groupId, newCap);
		shapeAnchorX = Arrays.copyOf(shapeAnchorX, newCap);
		shapeAnchorY = Arrays.copyOf(shapeAnchorY, newCap);
		shapeAnchorZ = Arrays.copyOf(shapeAnchorZ, newCap);
		worldSeed = Arrays.copyOf(worldSeed, newCap);
		capacity = newCap;
	}
}
