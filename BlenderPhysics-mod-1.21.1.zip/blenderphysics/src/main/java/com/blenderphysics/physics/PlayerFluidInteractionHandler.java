package com.blenderphysics.physics;

import com.blenderphysics.config.BlenderPhysicsConfig;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Física bidireccional entre las partículas de fluido realista y las entidades vivas:
 *  - Agua: arrastra según la corriente local y permite "nadar" con menos resistencia.
 *  - Lava: frena el movimiento un 85%, prende fuego y aplica daño periódico.
 *  - Slime: rebote conservando ~85% de la energía vertical de caída.
 *  - Toda entidad que se mueve DENTRO de un cuerpo de fluido empuja a las partículas
 *    cercanas (acoplamiento bidireccional real), generando olas/estelas visibles.
 *
 * Implementado como un manejador de evento de tick de servidor en vez de Mixins para
 * garantizar estabilidad frente a cambios de firma entre versiones de Minecraft/Yarn.
 */
public final class PlayerFluidInteractionHandler {

	private PlayerFluidInteractionHandler() {
	}

	private static final float INTERACTION_RADIUS = 1.1f;

	public static void tick(ServerWorld world) {
		BlenderPhysicsConfig cfg = BlenderPhysicsConfig.get();
		FluidSimulationWorld sim = PhysicsManager.get().simulationFor(world);
		FluidParticleBuffer buf = sim.buffer();
		long worldKey = sim.worldKey();
		int n = buf.highWaterMark();
		if (n == 0) return;

		List<ServerPlayerEntity> players = world.getPlayers();
		for (ServerPlayerEntity player : players) {
			Box box = player.getBoundingBox().expand(INTERACTION_RADIUS * 0.4);
			double cx = box.getCenter().x, cy = box.getCenter().y, cz = box.getCenter().z;

			float sumVx = 0, sumVy = 0, sumVz = 0;
			int touched = 0;
			int dominantType = -1;
			int[] typeCounts = new int[3];

			for (int i = 0; i < n; i++) {
				if (!buf.active[i] || buf.worldSeed[i] != worldKey) continue;
				if (buf.posX[i] < box.minX - 0.2 || buf.posX[i] > box.maxX + 0.2) continue;
				if (buf.posY[i] < box.minY - 0.2 || buf.posY[i] > box.maxY + 0.2) continue;
				if (buf.posZ[i] < box.minZ - 0.2 || buf.posZ[i] > box.maxZ + 0.2) continue;

				sumVx += buf.velX[i];
				sumVy += buf.velY[i];
				sumVz += buf.velZ[i];
				typeCounts[buf.type[i]]++;
				touched++;

				// acoplamiento bidireccional: el movimiento del jugador empuja la partícula
				Vec3d playerVel = player.getVelocity();
				buf.velX[i] += (float) playerVel.x * 0.15f;
				buf.velY[i] += (float) playerVel.y * 0.10f;
				buf.velZ[i] += (float) playerVel.z * 0.15f;
			}

			if (touched == 0) continue;
			int best = 0;
			for (int t = 1; t < 3; t++) if (typeCounts[t] > typeCounts[best]) best = t;
			dominantType = best;
			FluidType type = FluidType.byId(dominantType);

			Vec3d avgCurrent = new Vec3d(sumVx / touched, sumVy / touched, sumVz / touched);

			switch (type) {
				case WATER -> applyWaterEffects(player, avgCurrent, cfg);
				case LAVA -> applyLavaEffects(player, cfg);
				case SLIME -> applySlimeEffects(player);
			}
		}
	}

	private static void applyWaterEffects(ServerPlayerEntity player, Vec3d current, BlenderPhysicsConfig cfg) {
		if (!cfg.playerPushEnabled) return;
		Vec3d vel = player.getVelocity();
		Vec3d pushed = vel.add(current.multiply(0.04));
		player.setVelocity(pushed);
		player.velocityModified = true;
		player.fallDistance = 0;
	}

	private static void applyLavaEffects(ServerPlayerEntity player, BlenderPhysicsConfig cfg) {
		Vec3d vel = player.getVelocity();
		player.setVelocity(vel.multiply(0.15)); // frena un 85%
		player.velocityModified = true;
		player.setFireTicks(Math.max(player.getFireTicks(), 60));
		if (player.age % 10 == 0) {
			DamageSource fireDamage = player.getDamageSources().lava();
			player.damage(fireDamage, 2.0f);
		}
	}

	private static void applySlimeEffects(ServerPlayerEntity player) {
		if (player.fallDistance > 3.0f && player.getVelocity().y < -0.3) {
			double bounceEnergy = 0.85;
			Vec3d vel = player.getVelocity();
			player.setVelocity(vel.x, Math.abs(vel.y) * bounceEnergy, vel.z);
			player.velocityModified = true;
			player.fallDistance = 0;
		}
	}
}
