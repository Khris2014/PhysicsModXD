package com.blenderphysics.config;

/**
 * Calidad del shader de agua (pestaña Rendimiento del menú de configuración).
 */
public enum WaterShaderQuality {
	ULTRA_BLENDER("blenderphysics.config.quality.ultra"),
	MEDIUM("blenderphysics.config.quality.medium"),
	LOW("blenderphysics.config.quality.low");

	private final String translationKey;

	WaterShaderQuality(String translationKey) {
		this.translationKey = translationKey;
	}

	public String getTranslationKey() {
		return translationKey;
	}

	public WaterShaderQuality next() {
		WaterShaderQuality[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}
}
