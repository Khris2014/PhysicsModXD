package com.blenderphysics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.blenderphysics.BlenderPhysicsMod;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Configuración global del mod, en vivo y persistida en config/blenderphysics.json.
 * Esta clase es intencionalmente un simple contenedor de datos (POJO) para que Gson
 * pueda serializarla/deserializarla directamente. Todos los valores tienen límites
 * (clamp) aplicados por los setters usados desde la GUI, de modo que nunca se pueda
 * guardar un estado fuera de rango incluso si el json se edita a mano.
 *
 * NOTA (servidores dedicados): en un dedicated server sin cliente, esta configuración
 * se lee únicamente del archivo de configuración del lado servidor; la GUI solo existe
 * en el cliente integrado / singleplayer. Para multijugador formal se recomendaría
 * sincronizar los valores "de físicas" (gravedad, viscosidad, empuje) mediante un paquete
 * S2C al conectar; el gancho está preparado en {@link #toSyncString()} / {@link #fromSyncString(String)}.
 */
public final class BlenderPhysicsConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static BlenderPhysicsConfig INSTANCE;

	// ----- Pestaña 1: Rendimiento (Anti-Lag) -----
	public int maxParticles = 8000;          // 1,000 - 30,000
	public int simulationRadius = 32;        // 12 - 64
	public WaterShaderQuality waterShaderQuality = WaterShaderQuality.ULTRA_BLENDER;
	public int physicsSubsteps = 2;          // 1 - 4

	// ----- Pestaña 2: Apariencia Visual (Anti-Leche) -----
	public float waterClarity = 1.0f;        // 0.1 - 2.0
	public float foamAmount = 0.05f;         // 0.0 - 0.30 (5% por defecto)
	public float refractionIntensity = 0.6f; // 0.0 - 1.0
	public float lavaEmission = 1.0f;        // 0.5 - 2.0

	// ----- Pestaña 3: Físicas del Mundo -----
	public float gravity = 1.0f;             // -2.0 - 2.0
	public float waterViscosity = 0.35f;     // 0.0 - 5.0
	public float lavaViscosity = 3.5f;       // 0.0 - 5.0
	public float slimeViscosity = 1.8f;      // 0.0 - 5.0
	public boolean playerPushEnabled = true;

	public static final int MIN_PARTICLES = 1000;
	public static final int MAX_PARTICLES = 30000;
	public static final int MIN_RADIUS = 12;
	public static final int MAX_RADIUS = 64;
	public static final int MIN_SUBSTEPS = 1;
	public static final int MAX_SUBSTEPS = 4;

	private BlenderPhysicsConfig() {
	}

	public static BlenderPhysicsConfig get() {
		if (INSTANCE == null) {
			INSTANCE = load();
		}
		return INSTANCE;
	}

	private static Path configPath() {
		return BlenderPhysicsMod.getConfigDir().resolve("blenderphysics.json");
	}

	public static BlenderPhysicsConfig load() {
		Path path = configPath();
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				BlenderPhysicsConfig cfg = GSON.fromJson(reader, BlenderPhysicsConfig.class);
				if (cfg != null) {
					cfg.clampAll();
					return cfg;
				}
			} catch (IOException | RuntimeException e) {
				BlenderPhysicsMod.LOGGER.warn("No se pudo leer config/blenderphysics.json, usando valores por defecto.", e);
			}
		}
		BlenderPhysicsConfig fresh = new BlenderPhysicsConfig();
		fresh.save();
		return fresh;
	}

	public void save() {
		clampAll();
		try {
			Path path = configPath();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			BlenderPhysicsMod.LOGGER.error("No se pudo guardar config/blenderphysics.json", e);
		}
	}

	/** Aplica límites estrictos a todos los campos (se llama antes de guardar o tras cargar). */
	public void clampAll() {
		maxParticles = clamp(maxParticles, MIN_PARTICLES, MAX_PARTICLES);
		simulationRadius = clamp(simulationRadius, MIN_RADIUS, MAX_RADIUS);
		physicsSubsteps = clamp(physicsSubsteps, MIN_SUBSTEPS, MAX_SUBSTEPS);
		if (waterShaderQuality == null) waterShaderQuality = WaterShaderQuality.ULTRA_BLENDER;

		waterClarity = clamp(waterClarity, 0.1f, 2.0f);
		foamAmount = clamp(foamAmount, 0.0f, 0.30f);
		refractionIntensity = clamp(refractionIntensity, 0.0f, 1.0f);
		lavaEmission = clamp(lavaEmission, 0.5f, 2.0f);

		gravity = clamp(gravity, -2.0f, 2.0f);
		waterViscosity = clamp(waterViscosity, 0.0f, 5.0f);
		lavaViscosity = clamp(lavaViscosity, 0.0f, 5.0f);
		slimeViscosity = clamp(slimeViscosity, 0.0f, 5.0f);
	}

	private static int clamp(int v, int min, int max) {
		return Math.max(min, Math.min(max, v));
	}

	private static float clamp(float v, float min, float max) {
		return Math.max(min, Math.min(max, v));
	}

	/** Restaura los valores por defecto de fábrica y guarda. */
	public void resetToDefaults() {
		BlenderPhysicsConfig defaults = new BlenderPhysicsConfig();
		this.maxParticles = defaults.maxParticles;
		this.simulationRadius = defaults.simulationRadius;
		this.waterShaderQuality = defaults.waterShaderQuality;
		this.physicsSubsteps = defaults.physicsSubsteps;
		this.waterClarity = defaults.waterClarity;
		this.foamAmount = defaults.foamAmount;
		this.refractionIntensity = defaults.refractionIntensity;
		this.lavaEmission = defaults.lavaEmission;
		this.gravity = defaults.gravity;
		this.waterViscosity = defaults.waterViscosity;
		this.lavaViscosity = defaults.lavaViscosity;
		this.slimeViscosity = defaults.slimeViscosity;
		this.playerPushEnabled = defaults.playerPushEnabled;
		save();
	}

	/** Serialización compacta para un futuro paquete de sincronización S2C. */
	public String toSyncString() {
		return GSON.toJson(this);
	}

	public static void fromSyncString(String json) {
		try {
			BlenderPhysicsConfig cfg = GSON.fromJson(json, BlenderPhysicsConfig.class);
			if (cfg != null) {
				cfg.clampAll();
				INSTANCE = cfg;
			}
		} catch (RuntimeException e) {
			BlenderPhysicsMod.LOGGER.warn("Paquete de sincronización de configuración inválido.", e);
		}
	}
}
