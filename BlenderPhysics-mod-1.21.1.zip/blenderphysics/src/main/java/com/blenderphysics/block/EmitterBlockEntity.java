package com.blenderphysics.block;

import com.blenderphysics.physics.FluidType;
import com.blenderphysics.physics.PhysicsManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Bloque emisor: genera un chorro continuo de partículas de fluido realista mientras
 * esté activo (activado por Redstone o por click derecho). No es infinito sin control:
 * respeta siempre el límite global de partículas de la configuración.
 */
public class EmitterBlockEntity extends BlockEntity {

	private final FluidType fluidType;
	private boolean active = false;
	private int tickCounter = 0;

	public EmitterBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state, FluidType fluidType) {
		super(type, pos, state);
		this.fluidType = fluidType;
	}

	public void toggle() {
		active = !active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isActive() {
		return active;
	}

	public static void serverTick(net.minecraft.world.World world, BlockPos pos, BlockState state, EmitterBlockEntity be) {
		if (!be.active) return;
		be.tickCounter++;
		if (be.tickCounter % 4 != 0) return; // emite cada 4 ticks (~5 veces/seg) para no saturar
		if (!(world instanceof ServerWorld serverWorld)) return;

		Direction facing = state.contains(net.minecraft.state.property.Properties.FACING)
				? state.get(net.minecraft.state.property.Properties.FACING) : Direction.UP;
		Vec3d emitPos = Vec3d.ofCenter(pos).add(facing.getOffsetX() * 0.6, facing.getOffsetY() * 0.6, facing.getOffsetZ() * 0.6);

		PhysicsManager.get().spawnBurst(serverWorld, emitPos, be.fluidType, 12, 0.25f, 0.05f);
	}
}
