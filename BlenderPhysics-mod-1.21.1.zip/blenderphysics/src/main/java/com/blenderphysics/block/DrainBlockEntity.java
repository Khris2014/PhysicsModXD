package com.blenderphysics.block;

import com.blenderphysics.physics.PhysicsManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/**
 * Desagüe / sumidero: absorbe (elimina) cualquier partícula de fluido realista que
 * se acerque a este bloque. Permite construir fuentes y piscinas controladas sin
 * riesgo de inundar el mundo ni de acumular partículas indefinidamente (lo que
 * causaría lag). Se registra/desregistra automáticamente al cargar/descargar.
 */
public class DrainBlockEntity extends BlockEntity {

	public DrainBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.FLUID_DRAIN, pos, state);
	}

	@Override
	public void setWorld(net.minecraft.world.World world) {
		super.setWorld(world);
		if (world instanceof ServerWorld serverWorld) {
			PhysicsManager.get().simulationFor(serverWorld).registerDrain(getPos());
		}
	}

	@Override
	public void markRemoved() {
		super.markRemoved();
		if (getWorld() instanceof ServerWorld serverWorld) {
			PhysicsManager.get().simulationFor(serverWorld).unregisterDrain(getPos());
		}
	}
}
