package com.blenderphysics.block;

import com.blenderphysics.BlenderPhysicsMod;
import com.blenderphysics.registry.ModBlocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlockEntities {

	public static BlockEntityType<EmitterBlockEntity> WATER_EMITTER;
	public static BlockEntityType<EmitterBlockEntity> LAVA_EMITTER;
	public static BlockEntityType<EmitterBlockEntity> SLIME_EMITTER;
	public static BlockEntityType<DrainBlockEntity> FLUID_DRAIN;

	private ModBlockEntities() {
	}

	public static void register() {
		WATER_EMITTER = Registry.register(Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, "water_emitter"),
				BlockEntityType.Builder.create((pos, state) -> new EmitterBlockEntity(WATER_EMITTER, pos, state, com.blenderphysics.physics.FluidType.WATER),
						ModBlocks.WATER_EMITTER).build());

		LAVA_EMITTER = Registry.register(Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, "lava_emitter"),
				BlockEntityType.Builder.create((pos, state) -> new EmitterBlockEntity(LAVA_EMITTER, pos, state, com.blenderphysics.physics.FluidType.LAVA),
						ModBlocks.LAVA_EMITTER).build());

		SLIME_EMITTER = Registry.register(Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, "slime_emitter"),
				BlockEntityType.Builder.create((pos, state) -> new EmitterBlockEntity(SLIME_EMITTER, pos, state, com.blenderphysics.physics.FluidType.SLIME),
						ModBlocks.SLIME_EMITTER).build());

		FLUID_DRAIN = Registry.register(Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, "fluid_drain"),
				BlockEntityType.Builder.create(DrainBlockEntity::new, ModBlocks.FLUID_DRAIN).build());
	}
}
