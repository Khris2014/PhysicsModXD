package com.blenderphysics.block;

import com.blenderphysics.physics.FluidType;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Bloque técnico emisor de fluido realista (grifo de agua / inyector de magma /
 * dispensador de gelatina, según el {@link FluidType} con el que se construye).
 * Se activa con Redstone o con click derecho; jamás genera bloques de fluido vanilla.
 */
public class EmitterBlock extends BlockWithEntity {

	private final FluidType fluidType;
	private static final VoxelShape SHAPE = VoxelShapes.cuboid(0.1, 0.0, 0.1, 0.9, 0.9, 0.9);

	public EmitterBlock(FluidType fluidType, Settings settings) {
		super(settings.pistonBehavior(net.minecraft.block.piston.PistonBehavior.BLOCK));
		this.fluidType = fluidType;
		setDefaultState(getStateManager().getDefaultState().with(Properties.FACING, net.minecraft.util.math.Direction.UP));
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(Properties.FACING);
	}

	/** Orienta el emisor según la cara del bloque clicada al colocarlo (como un dispensador). */
	@Override
	public BlockState getPlacementState(net.minecraft.item.ItemPlacementContext ctx) {
		return getDefaultState().with(Properties.FACING, ctx.getSide());
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	protected MapCodec<? extends BlockWithEntity> getCodec() {
		return createCodec(settings -> new EmitterBlock(fluidType, settings));
	}

	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return switch (fluidType) {
			case WATER -> new WaterEmitterBlockEntity(pos, state);
			case LAVA -> new LavaEmitterBlockEntity(pos, state);
			case SLIME -> new SlimeEmitterBlockEntity(pos, state);
		};
	}

	@Override
	protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
		if (!world.isClient && world.getBlockEntity(pos) instanceof EmitterBlockEntity be) {
			be.toggle();
			player.sendMessage(net.minecraft.text.Text.translatable(
					be.isActive() ? "blenderphysics.message.emitter_on" : "blenderphysics.message.emitter_off"), true);
		}
		return ActionResult.SUCCESS;
	}

	@Override
	public void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
		// La Redstone solo puede ENCENDER el emisor; apagarlo manualmente se hace con click derecho,
		// para que el jugador conserve control total aunque el circuito de redstone siga activo.
		if (!world.isClient && world.isReceivingRedstonePower(pos)
				&& world.getBlockEntity(pos) instanceof EmitterBlockEntity be) {
			be.setActive(true);
		}
	}

	@Override
	protected net.minecraft.block.BlockRenderType getRenderType(BlockState state) {
		return net.minecraft.block.BlockRenderType.MODEL;
	}

	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
		return world.isClient ? null : (w, pos, st, be) -> {
			if (be instanceof EmitterBlockEntity emitter) {
				EmitterBlockEntity.serverTick(w, pos, st, emitter);
			}
		};
	}

	private static class WaterEmitterBlockEntity extends EmitterBlockEntity {
		WaterEmitterBlockEntity(BlockPos pos, BlockState state) {
			super(ModBlockEntities.WATER_EMITTER, pos, state, FluidType.WATER);
		}
	}

	private static class LavaEmitterBlockEntity extends EmitterBlockEntity {
		LavaEmitterBlockEntity(BlockPos pos, BlockState state) {
			super(ModBlockEntities.LAVA_EMITTER, pos, state, FluidType.LAVA);
		}
	}

	private static class SlimeEmitterBlockEntity extends EmitterBlockEntity {
		SlimeEmitterBlockEntity(BlockPos pos, BlockState state) {
			super(ModBlockEntities.SLIME_EMITTER, pos, state, FluidType.SLIME);
		}
	}
}
