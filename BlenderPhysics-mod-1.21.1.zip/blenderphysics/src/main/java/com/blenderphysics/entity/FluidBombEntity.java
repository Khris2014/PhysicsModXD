package com.blenderphysics.entity;

import com.blenderphysics.physics.FluidType;
import com.blenderphysics.physics.PhysicsManager;
import com.blenderphysics.registry.ModEntities;
import com.blenderphysics.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

/**
 * Granada lanzable de fluido realista. Al impactar genera una explosión de partículas
 * SPH del tipo correspondiente (agua/lava/slime) en un radio pequeño, sin destruir
 * terreno ni colocar bloques de fluido vanilla.
 */
public class FluidBombEntity extends ThrownItemEntity {

	private FluidType fluidType = FluidType.WATER;

	public FluidBombEntity(EntityType<? extends ThrownItemEntity> type, World world) {
		super(type, world);
	}

	public FluidBombEntity(World world, LivingEntity owner, FluidType type) {
		super(ModEntities.bombEntityFor(type), owner, world);
		this.fluidType = type;
	}

	public void setFluidType(FluidType type) {
		this.fluidType = type;
	}

	@Override
	protected Item getDefaultItem() {
		return switch (fluidType) {
			case WATER -> ModItems.WATER_BOMB;
			case LAVA -> ModItems.LAVA_BOMB;
			case SLIME -> ModItems.SLIME_BOMB;
		};
	}

	@Override
	protected void onCollision(HitResult hitResult) {
		super.onCollision(hitResult);
		if (!getWorld().isClient && getWorld() instanceof ServerWorld serverWorld) {
			int count = fluidType == FluidType.SLIME ? 180 : 220;
			PhysicsManager.get().spawnBurst(serverWorld, hitResult.getPos(), fluidType, count, 1.1f, 0.2f);
			discard();
		}
	}
}
