package com.blenderphysics.entity;

import com.blenderphysics.physics.BlockDensityTable;
import com.blenderphysics.registry.ModEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Entidad física 3D genérica creada por la Varita de Realismo: representa un bloque
 * arrancado del mundo (conserva su textura exacta vía BlockState) o un ítem convertido
 * con hitbox sólida. Tiene gravedad, rotación libre (cuaternión) y flotabilidad de
 * Arquímedes cuando queda sumergida en partículas de fluido realista.
 *
 * NOTA DE COMPATIBILIDAD: las firmas de initDataTracker / readCustomDataFromNbt /
 * writeCustomDataToNbt corresponden a los mappings Yarn de Minecraft 1.21.1. Si una
 * build futura de Yarn renombra estos métodos (por ejemplo al introducir NbtReadView/
 * NbtWriteView en versiones posteriores), ajustar las firmas según indique el compilador.
 */
public class PhysicsRigidBodyEntity extends Entity {

	private static final TrackedData<ItemStack> PAYLOAD_ITEM =
			DataTracker.registerData(PhysicsRigidBodyEntity.class, TrackedDataHandlerRegistry.ITEM_STACK);
	private static final TrackedData<Boolean> IS_BLOCK =
			DataTracker.registerData(PhysicsRigidBodyEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

	private BlockState sourceBlockState;
	private float density = 1.8f;

	public final Quaternionf rotation = new Quaternionf();
	public final Vector3f angularVelocity = new Vector3f(0, 0, 0);
	private int groundedTicks = 0;

	public PhysicsRigidBodyEntity(EntityType<?> type, World world) {
		super(type, world);
	}

	public static PhysicsRigidBodyEntity fromBlock(World world, BlockState state, Vec3d pos) {
		PhysicsRigidBodyEntity e = new PhysicsRigidBodyEntity(ModEntities.PHYSICS_RIGID_BODY, world);
		e.setPosition(pos);
		e.sourceBlockState = state;
		e.density = BlockDensityTable.densityOf(state);
		e.dataTracker.set(IS_BLOCK, true);
		Identifier id = Registries.BLOCK.getId(state.getBlock());
		e.dataTracker.set(PAYLOAD_ITEM, new ItemStack(net.minecraft.item.Items.AIR));
		e.blockId = id.toString();
		float r = 0.5f;
		e.setBoundingBox(new Box(pos.x - r, pos.y - r, pos.z - r, pos.x + r, pos.y + r, pos.z + r));
		e.angularVelocity.set(
				(world.random.nextFloat() - 0.5f) * 0.1f,
				(world.random.nextFloat() - 0.5f) * 0.1f,
				(world.random.nextFloat() - 0.5f) * 0.1f);
		return e;
	}

	public static PhysicsRigidBodyEntity fromItemStack(World world, ItemStack stack, Vec3d pos) {
		PhysicsRigidBodyEntity e = new PhysicsRigidBodyEntity(ModEntities.PHYSICS_RIGID_BODY, world);
		e.setPosition(pos);
		e.dataTracker.set(IS_BLOCK, false);
		e.dataTracker.set(PAYLOAD_ITEM, stack.copy());
		e.density = 1.2f;
		float r = 0.25f;
		e.setBoundingBox(new Box(pos.x - r, pos.y - r, pos.z - r, pos.x + r, pos.y + r, pos.z + r));
		return e;
	}

	/** Identificador textual del bloque origen (persistido aparte porque BlockState no es serializable directo). */
	private String blockId;

	public BlockState getSourceBlockState() {
		if (sourceBlockState == null && blockId != null) {
			Block b = Registries.BLOCK.get(Identifier.of(blockId));
			sourceBlockState = b.getDefaultState();
		}
		return sourceBlockState;
	}

	public boolean isBlockPayload() {
		return this.dataTracker.get(IS_BLOCK);
	}

	public ItemStack getItemPayload() {
		return this.dataTracker.get(PAYLOAD_ITEM);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(PAYLOAD_ITEM, ItemStack.EMPTY);
		builder.add(IS_BLOCK, true);
	}

	@Override
	public void tick() {
		super.tick();
		if (getWorld().isClient) {
			// rotación visual suave en el cliente (se corrige con la gravedad/colisión en servidor)
			rotation.integrate(0.05f, angularVelocity.x, angularVelocity.y, angularVelocity.z);
			return;
		}

		double submersion = estimateSubmersion();
		double gravity = 0.04 * densityGravityScale();
		double buoyancy = submersion > 0 ? (1.0 / Math.max(density, 0.2)) * submersion * 0.09 : 0;

		Vec3d vel = getVelocity();
		double ny = vel.y - gravity + buoyancy;
		if (submersion > 0.1) {
			ny *= 0.92; // amortiguación al estar sumergido (arrastre de fluido)
		}
		setVelocity(vel.x * 0.98, ny, vel.z * 0.98);

		move(MovementType.SELF, getVelocity());

		if (isOnGround()) {
			groundedTicks++;
			angularVelocity.mul(0.8f);
			if (groundedTicks > 20) {
				setVelocity(getVelocity().multiply(0.6, 1.0, 0.6));
			}
		} else {
			groundedTicks = 0;
		}

		rotation.integrate(0.05f, angularVelocity.x, angularVelocity.y, angularVelocity.z);

		if (age > 20 * 60 * 5) { // auto-limpieza tras 5 minutos para evitar acumulación infinita
			discard();
		}
	}

	private double densityGravityScale() {
		return Math.min(2.0, 0.6 + density * 0.1);
	}

	/** Aproximación barata: cuenta si el centro de la entidad está dentro de agua/lava realista cercana. */
	private double estimateSubmersion() {
		com.blenderphysics.physics.FluidSimulationWorld sim =
				com.blenderphysics.physics.PhysicsManager.get().simulationFor((net.minecraft.server.world.ServerWorld) getWorld());
		var buf = sim.buffer();
		int n = buf.highWaterMark();
		int nearby = 0;
		for (int i = 0; i < n; i++) {
			if (!buf.active[i]) continue;
			double dx = buf.posX[i] - getX();
			double dy = buf.posY[i] - getY();
			double dz = buf.posZ[i] - getZ();
			if (dx * dx + dy * dy + dz * dz < 0.7 * 0.7) nearby++;
			if (nearby > 40) break;
		}
		return Math.min(1.0, nearby / 12.0);
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		this.blockId = nbt.contains("BlockId") ? nbt.getString("BlockId") : null;
		this.density = nbt.getFloat("Density");
		this.dataTracker.set(IS_BLOCK, nbt.getBoolean("IsBlock"));
		if (nbt.contains("Item")) {
			ItemStack.fromNbt(getWorld().getRegistryManager(), nbt.getCompound("Item")).ifPresent(
					stack -> this.dataTracker.set(PAYLOAD_ITEM, stack));
		}
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		if (blockId != null) nbt.putString("BlockId", blockId);
		nbt.putFloat("Density", density);
		nbt.putBoolean("IsBlock", isBlockPayload());
		if (!getItemPayload().isEmpty()) {
			nbt.put("Item", getItemPayload().encode(getWorld().getRegistryManager()));
		}
	}

	@Override
	public net.minecraft.network.packet.Packet<net.minecraft.network.listener.ClientPlayPacketListener> createSpawnPacket() {
		return new EntitySpawnS2CPacket(this);
	}

	@Override
	public boolean shouldRender(double distance) {
		return distance < 64 * 64;
	}
}
