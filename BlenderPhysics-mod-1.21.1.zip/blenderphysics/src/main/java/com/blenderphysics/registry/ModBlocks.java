package com.blenderphysics.registry;

import com.blenderphysics.BlenderPhysicsMod;
import com.blenderphysics.block.DrainBlock;
import com.blenderphysics.block.EmitterBlock;
import com.blenderphysics.physics.FluidType;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {

	public static Block WATER_EMITTER;
	public static Block LAVA_EMITTER;
	public static Block SLIME_EMITTER;
	public static Block FLUID_DRAIN;

	private ModBlocks() {
	}

	private static Block register(String name, Block block) {
		return Registry.register(Registries.BLOCK, Identifier.of(BlenderPhysicsMod.MOD_ID, name), block);
	}

	public static void register() {
		WATER_EMITTER = register("water_emitter", new EmitterBlock(FluidType.WATER,
				AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE).strength(2.0f).nonOpaque()));
		LAVA_EMITTER = register("lava_emitter", new EmitterBlock(FluidType.LAVA,
				AbstractBlock.Settings.create().mapColor(MapColor.ORANGE).strength(2.0f).luminance(state -> 8).nonOpaque()));
		SLIME_EMITTER = register("slime_emitter", new EmitterBlock(FluidType.SLIME,
				AbstractBlock.Settings.create().mapColor(MapColor.GREEN).strength(1.5f).nonOpaque()));
		FLUID_DRAIN = register("fluid_drain", new DrainBlock(
				AbstractBlock.Settings.create().mapColor(MapColor.STONE_GRAY).strength(2.5f).nonOpaque()));
	}
}
