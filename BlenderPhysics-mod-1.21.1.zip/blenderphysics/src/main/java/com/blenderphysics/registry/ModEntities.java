package com.blenderphysics.registry;

import com.blenderphysics.BlenderPhysicsMod;
import com.blenderphysics.entity.FluidBombEntity;
import com.blenderphysics.entity.PhysicsRigidBodyEntity;
import com.blenderphysics.physics.FluidType;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {

	public static EntityType<PhysicsRigidBodyEntity> PHYSICS_RIGID_BODY;
	public static EntityType<FluidBombEntity> WATER_BOMB_ENTITY;
	public static EntityType<FluidBombEntity> LAVA_BOMB_ENTITY;
	public static EntityType<FluidBombEntity> SLIME_BOMB_ENTITY;

	private ModEntities() {
	}

	public static void register() {
		PHYSICS_RIGID_BODY = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, "physics_rigid_body"),
				EntityType.Builder.<PhysicsRigidBodyEntity>create(PhysicsRigidBodyEntity::new, SpawnGroup.MISC)
						.dimensions(EntityDimensions.fixed(1.0f, 1.0f))
						.maxTrackingRange(64)
						.trackingTickInterval(2)
						.build());

		WATER_BOMB_ENTITY = registerBomb("water_bomb_entity");
		LAVA_BOMB_ENTITY = registerBomb("lava_bomb_entity");
		SLIME_BOMB_ENTITY = registerBomb("slime_bomb_entity");
	}

	private static EntityType<FluidBombEntity> registerBomb(String name) {
		return Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(BlenderPhysicsMod.MOD_ID, name),
				EntityType.Builder.<FluidBombEntity>create(FluidBombEntity::new, SpawnGroup.MISC)
						.dimensions(EntityDimensions.fixed(0.25f, 0.25f))
						.maxTrackingRange(32)
						.trackingTickInterval(4)
						.build());
	}

	public static EntityType<FluidBombEntity> bombEntityFor(FluidType type) {
		return switch (type) {
			case WATER -> WATER_BOMB_ENTITY;
			case LAVA -> LAVA_BOMB_ENTITY;
			case SLIME -> SLIME_BOMB_ENTITY;
		};
	}
}
