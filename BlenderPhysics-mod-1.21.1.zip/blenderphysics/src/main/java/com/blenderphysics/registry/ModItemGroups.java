package com.blenderphysics.registry;

import com.blenderphysics.BlenderPhysicsMod;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroups {

	public static final RegistryKey<ItemGroup> BLENDER_PHYSICS_KEY = RegistryKey.of(
			RegistryKeys.ITEM_GROUP, Identifier.of(BlenderPhysicsMod.MOD_ID, "blender_physics"));

	public static ItemGroup BLENDER_PHYSICS;

	private ModItemGroups() {
	}

	public static void register() {
		BLENDER_PHYSICS = Registry.register(Registries.ITEM_GROUP, BLENDER_PHYSICS_KEY,
				ItemGroup.create(ItemGroup.Row.TOP, 0)
						.icon(() -> new ItemStack(ModItems.REALITY_WAND))
						.displayName(Text.translatable("itemGroup.blenderphysics.blender_physics"))
						.entries((displayContext, entries) -> {
							entries.add(ModItems.REALITY_WAND);
							entries.add(ModItems.REALISTIC_WATER_BUCKET);
							entries.add(ModItems.REALISTIC_LAVA_BUCKET);
							entries.add(ModItems.REALISTIC_SLIME_BUCKET);
							entries.add(ModItems.WATER_BOMB);
							entries.add(ModItems.LAVA_BOMB);
							entries.add(ModItems.SLIME_BOMB);
							entries.add(ModBlocks.WATER_EMITTER);
							entries.add(ModBlocks.LAVA_EMITTER);
							entries.add(ModBlocks.SLIME_EMITTER);
							entries.add(ModBlocks.FLUID_DRAIN);
						})
						.build());
	}
}
