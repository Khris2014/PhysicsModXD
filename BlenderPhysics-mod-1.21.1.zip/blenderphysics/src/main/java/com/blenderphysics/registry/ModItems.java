package com.blenderphysics.registry;

import com.blenderphysics.BlenderPhysicsMod;
import com.blenderphysics.item.FluidBombItem;
import com.blenderphysics.item.RealisticFluidBucketItem;
import com.blenderphysics.item.RealityWandItem;
import com.blenderphysics.physics.FluidType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {

	public static Item REALITY_WAND;
	public static Item REALISTIC_WATER_BUCKET;
	public static Item REALISTIC_LAVA_BUCKET;
	public static Item REALISTIC_SLIME_BUCKET;
	public static Item WATER_BOMB;
	public static Item LAVA_BOMB;
	public static Item SLIME_BOMB;

	public static Item WATER_EMITTER_ITEM;
	public static Item LAVA_EMITTER_ITEM;
	public static Item SLIME_EMITTER_ITEM;
	public static Item FLUID_DRAIN_ITEM;

	private ModItems() {
	}

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, Identifier.of(BlenderPhysicsMod.MOD_ID, name), item);
	}

	public static void register() {
		REALITY_WAND = register("reality_wand",
				new RealityWandItem(new Item.Settings().maxCount(1)));

		REALISTIC_WATER_BUCKET = register("realistic_water_bucket",
				new RealisticFluidBucketItem(FluidType.WATER, new Item.Settings().maxCount(1)));
		REALISTIC_LAVA_BUCKET = register("realistic_lava_bucket",
				new RealisticFluidBucketItem(FluidType.LAVA, new Item.Settings().maxCount(1)));
		REALISTIC_SLIME_BUCKET = register("realistic_slime_bucket",
				new RealisticFluidBucketItem(FluidType.SLIME, new Item.Settings().maxCount(1)));

		WATER_BOMB = register("water_bomb", new FluidBombItem(FluidType.WATER, new Item.Settings().maxCount(16)));
		LAVA_BOMB = register("lava_bomb", new FluidBombItem(FluidType.LAVA, new Item.Settings().maxCount(16)));
		SLIME_BOMB = register("slime_bomb", new FluidBombItem(FluidType.SLIME, new Item.Settings().maxCount(16)));

		WATER_EMITTER_ITEM = register("water_emitter", new BlockItem(ModBlocks.WATER_EMITTER, new Item.Settings()));
		LAVA_EMITTER_ITEM = register("lava_emitter", new BlockItem(ModBlocks.LAVA_EMITTER, new Item.Settings()));
		SLIME_EMITTER_ITEM = register("slime_emitter", new BlockItem(ModBlocks.SLIME_EMITTER, new Item.Settings()));
		FLUID_DRAIN_ITEM = register("fluid_drain", new BlockItem(ModBlocks.FLUID_DRAIN, new Item.Settings()));
	}
}
