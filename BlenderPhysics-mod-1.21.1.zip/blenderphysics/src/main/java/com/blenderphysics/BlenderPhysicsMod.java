package com.blenderphysics;

import com.blenderphysics.block.ModBlockEntities;
import com.blenderphysics.config.BlenderPhysicsConfig;
import com.blenderphysics.item.RealityWandItem;
import com.blenderphysics.physics.PhysicsManager;
import com.blenderphysics.physics.PlayerFluidInteractionHandler;
import com.blenderphysics.registry.ModBlocks;
import com.blenderphysics.registry.ModEntities;
import com.blenderphysics.registry.ModItemGroups;
import com.blenderphysics.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.entity.ItemEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Entrypoint común (servidor + cliente) del mod BlenderPhysics: Crystal Fluid & SoftBody Engine.
 * Registra ítems, bloques, entidades, el motor de físicas y el comando /bp.
 */
public class BlenderPhysicsMod implements ModInitializer {

	public static final String MOD_ID = "blenderphysics";
	public static final Logger LOGGER = LoggerFactory.getLogger("BlenderPhysics");

	private static Path configDir;

	@Override
	public void onInitialize() {
		configDir = net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir();

		ModBlocks.register();
		ModItems.register();
		ModBlockEntities.register();
		ModEntities.register();
		ModItemGroups.register();

		// Fuerza la carga de la configuración (crea config/blenderphysics.json si no existe)
		BlenderPhysicsConfig.get();

		registerEvents();
		registerCommands();

		LOGGER.info("BlenderPhysics: Crystal Fluid & SoftBody Engine inicializado.");
	}

	private void registerEvents() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			PhysicsManager.get().tickAll();
			for (net.minecraft.server.world.ServerWorld world : server.getWorlds()) {
				PlayerFluidInteractionHandler.tick(world);
			}
		});

		net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPING.register(server ->
				PhysicsManager.get().onServerStopping());

		UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
			if (!(entity instanceof ItemEntity itemEntity)) return ActionResult.PASS;
			if (!(player.getStackInHand(hand).getItem() instanceof RealityWandItem)) return ActionResult.PASS;
			return RealityWandItem.onUseOnItemEntity(player, world, itemEntity);
		});
	}

	private void registerCommands() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(literal("bp")
						.then(literal("clear")
								.requires(src -> src.hasPermissionLevel(2))
								.executes(ctx -> {
									PhysicsManager.get().clearAll();
									ctx.getSource().sendFeedback(() -> Text.translatable("blenderphysics.command.cleared"), true);
									return 1;
								}))
						.then(literal("configui")
								.executes(ctx -> {
									// La GUI de configuración solo existe en el cliente; en un comando de servidor
									// únicamente podemos indicar al jugador cómo abrirla localmente.
									ctx.getSource().sendFeedback(() -> Text.translatable("blenderphysics.command.configui_hint"), false);
									return 1;
								}))));
	}

	public static Path getConfigDir() {
		if (configDir == null) {
			configDir = Path.of("config"); // fallback de seguridad (p.ej. en tests unitarios)
		}
		return configDir;
	}
}
